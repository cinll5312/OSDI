#ifndef _TIMER_H_
#define _TIMER_H_

#define CORE0_TIMER_IRQ_CTRL  ((unsigned int*)0x40000040)
#define CORE1_TIMER_IRQ_CTRL  ((unsigned int*)0x40000044)
#define CORE2_TIMER_IRQ_CTRL  ((unsigned int*)0x40000048)
#define CORE3_TIMER_IRQ_CTRL  ((unsigned int*)0x4000004C)

void expire(unsigned long t);
void add_timer(unsigned long p);
void showtime();
void timer_handler();

#endif