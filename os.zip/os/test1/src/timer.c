#include "timer.h"
#include "uart.h"

extern void core_timer_enable();
extern void core_timer_disable();

void expire(unsigned long t)
{
    unsigned long f;
    asm volatile("mrs %0, cntfrq_el0\n\r" : "=r"(f):);
    asm volatile("msr cntp_tval_el0, %0\n\r":: "r"(t*f));
}

void add_timer(unsigned long p){
    enable_el1_interrupt();
    expire(p);
    core_timer_enable();
}

void showtime(){
    int count, f;
    int time = 0;
    asm volatile("mrs %[result], cntpct_el0": [result]"=r"(count));
    asm volatile("mrs %[result], cntfrq_el0": [result]"=r"(f));
    time = count /f;
    uart_puts("current time: ");
    if(time == 0)
        uart_puts("0");
    else
        print_num(time);
    uart_puts("\nTimer interrupt\n");
}

void timer_handler(){
    showtime();
    core_timer_disable();
}

void current_time(unsigned int* t)
{
    unsigned int tt;
    asm volatile("mrs %0, cntpct_el0" : "=r"(tt):);
    *t =tt;
}

