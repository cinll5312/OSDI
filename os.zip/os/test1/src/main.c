#include "uart.h"
#include "irq.h"

// #define IRQ_BASIC   ((volatile unsigned int *)(0x3F00B200))
// #define IRQ_PEND1   ((volatile unsigned int *)(0x3F00B204))
// #define IRQ_ENABLE1 ((volatile unsigned int *)(0x3F00B210))
// #define AUX_ENABLES ((volatile unsigned int *)(0x3F215004))
// #define AUX_MU_IO   ((volatile unsigned int *)(0x3F215040))
// #define AUX_MU_IER  ((volatile unsigned int *)(0x3F215044))
// #define AUX_MU_IIR  ((volatile unsigned int *)(0x3F215048))
// #define AUX_MU_LSR  ((volatile unsigned int *)(0x3F215054))
#define GPU_INTERRUPTS_ROUTING ((volatile unsigned int *)(0x4000000C))

void init()
{
	//enable el1 interrupt
	//enable_el1_interrupt();
	enable_irq();
	//uart init
	uart_init();

	//read asyn
	asyn_buf_init();
	//asyn_set();
}

void main(int argc, char *argv[]){
	
	//char* string = simple_malloc(8);
	
    init();
	uart_puts("Basic Shell\n\r");
	//print_hex(AUX_ENABLE);
	
	//add_timer(1);
	char buf[64];
	asyn_read(&buf, 64);
	
}