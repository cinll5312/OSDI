#include "irq.h"
#include "uart.h"

unsigned int write_buf[LEN];
unsigned int read_buf[LEN];

extern void enable_irq(void);
extern void disable_irq(void);

void irq_handler(unsigned int type, unsigned int spsr_el1, unsigned int elr_el1, unsigned int esr_el1)
{
    // switch(type){
    //     case 0: uart_puts("synchronous_sp_el0\n"); break;
    //     case 1: uart_puts("irq_sp_el0\n"); break;
    //     case 2: uart_puts("fiq_sp_el0\n"); break;
    //     case 3: uart_puts("serror_sp_el0\n"); break;
    //     case 4: uart_puts("synchronous_sp_elx\n"); break;
    //     case 5: uart_puts("irq_sp_elx\n"); break;
    //     case 6: uart_puts("fiq_sp-elx\n"); break;
    //     case 7: uart_puts("serror_sp_elx\n"); break;
    //     case 8: uart_puts("synchronous_aarch64\n"); break;
    //     case 9: uart_puts("irq_aarch64\n"); break;
    //     case 10: uart_puts("fiq_aarch64\n"); break;
    //     case 11: uart_puts("serror_aarch64\n"); break;
    //     case 12: uart_puts("synchronous_aarch32\n"); break;
    //     case 13: uart_puts("irq_aarch32\n"); break;
    //     case 14: uart_puts("fiq_aarch32\n"); break;
    //     case 15: uart_puts("serror_aarch32\n"); break;
    // }
    //uart_puts("irq_handler\n\r");
    disable_irq();
    if(*CORE0_IRQ_SOURCE & 0b10)
    {
        print_hex(*CORE0_IRQ_SOURCE);
        uart_puts("timer\n");
        timer_handler();
    }
    else if(*IRQ_PENDING_1 & (1 << 29))
    {
        char a = uart_recv_int();
        uart_send_c(a);
        
        //*AUX_MU_IER |= 1;

        
        //gpu_interrupt_handler();
    }
    else
    {
        uart_puts("No type\n\r");
        uart_puts("spsr_el1 : ");
        print_hex(spsr_el1);
        uart_puts("\nelr_el1 : ");
        print_hex(elr_el1);
        uart_puts("\nesr_el1 : ");
        print_hex(esr_el1);
        uart_puts("\n");
        while(1);
    }
    enable_irq();
}

void enable_el1_interrupt()
{
    asm volatile("msr DAIFClr, 0x2\n\r");  //enable el1 interrupt
}



void asyn_buf_init()
{
    recv_head = 0;
    recv_tail = 0;
    w_buf_head = 0;
    w_buf_tail = 0;
}

void gpu_interrupt_handler() {
    if ((*IRQ_PENDING_1)&(1<<29)) {
    // uart interrupt (actually aux interrupt)
        volatile unsigned int iir = *AUX_MU_IIR;
        if ((iir & 1) == 0) {
            if (iir & 2) {
                //uart_send_from_buf();
            // print("Transmit holding register empty\n");
            } else if (iir & 4) {
            // print("recv interrupt\n");
                //uart_recv_to_buf();
                char c = *AUX_MU_IO;  /* read for clear tx interrupt. */
                uart_puts(" c_irq_handler\n");
            }
        } else {
            uart_puts("Aux Interrupt Error \n");
        }
    }
    else
    {
        uart_puts(" c_irq_handler\n");
    }
}

void uart_send_c(unsigned char data) {
    while ((*AUX_MU_LSR & 0x20) == 0);
    *AUX_MU_IO = (unsigned int)data;
}

void uart_recv_to_buf()
{
    char c = uart_recv();
    recv_tail = (recv_tail+1)%LEN;
    write_buf[recv_tail] = c;
}

unsigned int asyn_read(char *str, unsigned int size)
{
    disable_irq();
    //*AUX_MU_CNTL = 0;
    *AUX_MU_IER = 1;

    /* UART interrupt routing. */
    *ENABLE_IRQS_1 = 1 << 29;
    //*AUX_MU_CNTL = 3;
    enable_irq();
    int i;
    for(i = 0; i < size-1; i++)
    {
        while(recv_head == recv_tail)
        {
            asm volatile("nop\n\r");
        }
        recv_head = (recv_head + 1) % LEN;
        if(write_buf[recv_head] == '\r' | write_buf[recv_head] == '\n')
        {
            break;
        }
        else
        {
            str[i] = write_buf[recv_head];
        }
        str[i] = '\0';
    }
    return i;
}
