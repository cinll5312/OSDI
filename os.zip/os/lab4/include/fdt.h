#ifndef _FDT_H_
#define _FDT_H_

#include "stdint.h"
#include "uart.h"
#include "utli.h"

typedef void(*dtb_callback_t)(int node_type, char* name, char* target, int len, void* value, void* target_addr);

unsigned int* fdt_addr;

#define FDT_ADDRESS     ((volatile unsigned int*)(fdt_addr))
#define FDT_MAGIC       ((volatile unsigned int*)(0xD00DFEED)) 
#define FDT_BEGIN_NODE  (0x00000001)
#define FDT_END_NODE    (0x00000002)
#define FDT_PROP        (0x00000003)
#define FDT_NOP         (0x00000004)
#define FDT_END         (0x00000009)

typedef struct{
    uint32_t magic;
    uint32_t totalsize;
    uint32_t off_dt_struct;
    uint32_t off_dt_strings;
    uint32_t off_mem_rsvmap;
    uint32_t version;
    uint32_t last_comp_version;
    uint32_t boot_cpuid_phys;
    uint32_t size_dt_strings;
    uint32_t size_dt_struct;
}fdt_header_t;

typedef struct {
    uint32_t len;
    uint32_t nameoff;
}fdt_prop_t;


uint32_t little2big(uint32_t num);

void parsing_dtb(char* target, int target_len, void *target_addr, dtb_callback_t callback);

void find_dtb(int node_type, char* name, char* target, int len, void* value, void* target_addr);
void fdt_init();
#endif*/
