#ifndef MM_H
#define MM_H
#include "stdint.h"
#include "uart.h"
#include "fdt.h"
#include "cpio.h"
//for simple allocator
//end of our heap we could allocate
#define MALLOC_SIZE 0x2000
//top of our heap
extern int brk;
extern int brk_end;
unsigned long simple_base;
unsigned long buddy_info_start;// frame list info
unsigned long mem_count;
int use_addr;

mm_info[MALLOC_SIZE];
int ram_find;
unsigned long ram_start;
unsigned long ram_end;
unsigned long buddy_start;
unsigned long buddy_end;
unsigned long mem_size;
//for buddy system
#define MEM_HEAD        (buddy_start)//(0x10000000)
#define MEM_TAIL        (buddy_end)//(0x20000000)
#define MEM_UNIT        (0x1000) //4K
// #define MEM_COUNT       ((buddy_end - buddy_start) / MEM_UNIT)
#define FRAME_TYPE_FREE ("F")
#define FRAME_TYPE_USE  ("U")
#define FRAME_LEVEL     (10) // 5 order

int frame_size[FRAME_LEVEL];//0x1000 * 1 2 4 8 16 32

typedef struct{
    int index;
    int val;
    void* next;
}frame_entry_t;

frame_entry_t* frame_list_head[FRAME_LEVEL];
frame_entry_t* frame_list_tail[FRAME_LEVEL];

//for dynamic allocator
static const int slab_pool_size[]={16,32,48,96,128,2048};

#define SLAB_LEVEL      (sizeof(slab_pool_size)/sizeof(slab_pool_size[0]))
#define SLAB_USE        (0)
#define SLAB_FREE       (1)
#define SLAB_END        (2)
#define SLAB_RESERVED   (FRAME_LEVEL-1)//allocate level from buddy system

typedef struct{
    int used;
    void* addr;
    void* next;
}slab_entry_t;//24

typedef struct{
    int total_size; //pool size
    int size; // which slab size pool
    int valid; //valid count
    void* next; // next valid cache with the same size
    slab_entry_t* valid_pool;
    slab_entry_t* use_pool;
}cache_info_t;//40

cache_info_t* slab_cache[SLAB_LEVEL];//cache info

//Reserved Memory
typedef struct res_mem reserved_mem_t;
struct res_mem{
    unsigned long start;
    unsigned long end;
    reserved_mem_t* next;
};

reserved_mem_t* res_mem_ptr;
void find_ram(int node_type, char* name, char* target, int len, void* value, void* target_addr);

//simple allocator
void *simple_malloc(int size);
void mm_init();
//reserved mem
void memory_reserved(unsigned long start, unsigned long end);
void startup_allocation();
//buddy system
void frame_init();
void* kmalloc(int size);//API;
void kfree();
void buddy_free(void* ptr);
int find_buddy_pfn(int order, unsigned long page_pfn);

//allocate buddy_system
frame_entry_t* buddy_allocate(int order);

//list operation
frame_entry_t* frame_list_pop(int order);
void frame_list_push(int order, frame_entry_t* frame);
void frame_list_remove(int order, frame_entry_t* frame);

//cut large space into smaller space
frame_entry_t* frame_free_redundant(int order, frame_entry_t* ptr);

//merge
void coalesce_frame(frame_entry_t* ptr);
int in_buddy_system(int order, frame_entry_t* ptr);
//debug
void p();
void pp(int order);

// dynamic_memory_allocator --> slab
void slab_init();
void* slab_cache_create(int size);
void* slab_allocator(int size);
void* get_slab_slot(cache_info_t* ptr);
void free_slab_slot(cache_info_t* ptr, void* addr);
int slab_free(void* ptr);


#endif