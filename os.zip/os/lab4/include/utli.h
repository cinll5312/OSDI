#ifndef UTLI_H
#define UTLI_H
#include "uart.h"
#include "stdint.h"
#define BUF_LEN 64

void *memset(void *s, int c, size_t count);
int cmpstr(const char* s1, const char* s2, int len);
void *memcpy(void *str1, const void *str2, size_t n);
int char2int(char* buf, int len);
int strlen(const char* s);
void get_el_c();
int read(char* buf, int len);
#endif