#include "uart.h"
#include "shell.h"
#include "mm.h"
#include "fdt.h"
#include "utli.h"
#include "timer.h"
#include "irq.h"
#include "cpio.h"
extern void exception_test_sample();

void init()
{
	uart_init();
	irq_init();
	time_init();
	fdt_init();
	mm_init();
}

void main(int argc, char *argv[])
{
	fdt_addr =  argc;
    init();
	
	uart_puts("Basic Shell\n\r");
	void* ptr = kmalloc(4096);
	uart_puts("malloc : ");
	print_hex(ptr);
	uart_puts("\n");
	// // free(ptr);
	void* ptrr = kmalloc(4096);
	uart_puts("malloc : ");
	print_hex(ptrr);
	uart_puts("\n");
	
	void* ptrrr = kmalloc(4096);
	uart_puts("malloc : ");
	print_hex(ptrrr);
	uart_puts("\n");
	// kfree(ptrr);
	ptrrr = kmalloc(4096);
	uart_puts("malloc : ");
	print_hex(ptrrr);
	uart_puts("\n");
	// ptrrr = kmalloc(16);
	// uart_puts("malloc : ");
	// print_hex(ptrrr);
	// uart_puts("\n");
	// kfree(ptrrr);
	// kfree(ptr);
	ptrrr = kmalloc(4096);
	uart_puts("malloc : ");
	print_hex(ptrrr);
	ptrrr = kmalloc(4096);
	uart_puts("malloc : ");
	print_hex(ptrrr);
	uart_puts("\n");
	ptrrr = kmalloc(4096);
	uart_puts("malloc : ");
	print_hex(ptrrr);
	uart_puts("\n");
	ptrrr = kmalloc(4096);
	uart_puts("malloc : ");
	print_hex(ptrrr);
	uart_puts("\n");
	while (1) {
		shell();
	}
}