#include "fdt.h"
#include "cpio.h"

// uint32_t align_up(uint32_t size, int alignment)
// {
//     return (size + alignment - 1) & -alignment;
// }

uint32_t little2big(uint32_t num)
{
    uint32_t res = 0;
    res = (num & 0x000000FF) << 24 |
          (num & 0x0000FF00) << 8  |
          (num & 0x00FF0000) >> 8  |
          (num & 0xFF000000) >> 24;
   
    return res; 
}
//0x801dbdd

 //https://www.kernel.org/doc/Documentation/devicetree/bindings/chosen.txt
//cpio
void parsing_dtb(char* target, int target_len, void *target_addr, dtb_callback_t callback)
{
    char buf[64];
    fdt_header_t* tmp = (fdt_header_t*)FDT_ADDRESS;
    uint32_t magic = little2big(tmp->magic);
    //print_hex(magic);
    if(FDT_MAGIC == magic)
    {
        uint32_t totalsize = little2big(tmp->totalsize);
        uint32_t off_dt_struct = little2big(tmp->off_dt_struct);
        uint32_t off_dt_strings = little2big(tmp->off_dt_strings);
        
        uint32_t size_dt_strings = little2big(tmp->size_dt_strings);
        uint32_t size_dt_struct = little2big(tmp->size_dt_struct);

        char* struct_start = ((char*)(FDT_ADDRESS) + off_dt_struct);
        char* struct_end = (char*)(struct_start + size_dt_struct);
        char* string_start = (char*)((char*)(FDT_ADDRESS) + (uint32_t)off_dt_strings);

        int addr_size = 0;
        int size = 0;
        int depth = 0;
        char* addr_start = struct_start;
        while(addr_start < struct_end)
        {
            uint32_t token = little2big(*(uint32_t*)addr_start);

            addr_start += 4;
            if(token == FDT_BEGIN_NODE)
            {
                char* devicename = (char*)addr_start;
                callback(token,devicename,target,target_len,0,target_addr);
                // uart_puts(devicename);
                
                //fp(token,&depth,&addr_size,&size,devicename,0);
                addr_start += sizeof(devicename);
                addr_start += ((uint32_t)addr_start%4==0)?0:(4-(uint32_t)addr_start%4);
            }
            else if(token == FDT_PROP)
            {
                
                uint32_t len = little2big(*((uint32_t*)addr_start));
                addr_start += 4;
                uint32_t nameoff = little2big(*((uint32_t*)addr_start));
                addr_start += 4;
                uint32_t nameoff_strings = string_start + nameoff;
                char* property = (char*)nameoff_strings;
                char* prop_value = (char*)addr_start;
                callback(token,property,target,target_len,prop_value,target_addr);
                addr_start += len;
                addr_start += ((uint32_t)addr_start%4==0)?0:(4-(uint32_t)addr_start%4);
                //fp(token,&depth,&addr_size,&size,property,prop_value);
                
            }
            else if(token == FDT_END_NODE)
            {
                
                //fp(token,&depth,0,0,0,0);
                callback(token,0,target,target_len,0,target_addr);
            }
            else if(token == FDT_NOP)
            {
                callback(token,0,target,target_len,0,target_addr);
            }
            else if(token == FDT_END)
            {
                //fp(token,&depth,0,0,0,0);
                callback(token,0,target,target_len,0,target_addr);
            }
            else
            {
                //uart_puts("error type\n");
            }
        }
    }
    else
    {
        uart_puts("error dtb\n");
    }
}

void find_dtb(int node_type, char* name, char* target, int len, void* value, void* target_addr)
{
    if(cmpstr(name,target,len))
    {
        *(uint32_t*)target_addr = little2big(*(uint32_t*)value);
    }
}


void fdt_init()
{
    //cpio
    parsing_dtb("linux,initrd-start", sizeof("linux,initrd-start"), &cpio_start, find_dtb);
    parsing_dtb("linux,initrd-end", sizeof("linux,initrd-end"), &cpio_end, find_dtb);
}

void fp(int token, int* depth_ptr, int* addr_size_ptr, int* size_ptr, char* name, void* prop_value)
{
    int depth = *depth_ptr;
    int addr_size = *addr_size_ptr; 
    int size = *size_ptr;
    if(token == FDT_PROP)
    {
        for(int i = 0; i < depth; i++)uart_puts(" ");
        uart_puts(name);
        uart_puts(" = ");
        if(cmpstr("#address-cells",name,sizeof("#address-cells")))
        {
            addr_size = little2big(*(uint32_t*)prop_value);
            print_hex(addr_size);
            uart_puts("\n");
            *addr_size_ptr = addr_size;
        }
        else if(cmpstr("#size-cells",name,sizeof("#size-cells")))
        {
            size = little2big(*(uint32_t*)prop_value);
            print_hex(size);
            uart_puts("\n");
            *size_ptr = size;
        }
        else if(cmpstr("device_type",name,sizeof("device_type"))||cmpstr("compatible",name,sizeof("compatible"))||cmpstr("model",name,sizeof("model"))||cmpstr("bootargs",name,sizeof("bootargs")))
        {
            uart_puts((char*)prop_value);
        }
        else
        {
            uart_puts("< ");
            for(int i = 0;  i < addr_size; i++)
            {
                print_hex(little2big(*(uint32_t*)prop_value));
                uart_puts(" ");
                prop_value = (char*)prop_value + 4;
            }
            
            if(size > 0)
            {
                for(int i = 0;  i < size; i++)
                {
                    print_hex(*(uint32_t*)prop_value);
                    uart_puts(" ");
                    prop_value = (char*)prop_value + 4;
                }  
            }
            uart_puts(">");
        }
        uart_puts("\n");
    }
    else if(token == FDT_BEGIN_NODE)
    {
        for(int i = 0; i < depth; i++)uart_puts(" ");
        uart_puts(name);
        uart_puts("{\n");
        depth++;
        *depth_ptr = depth;
    }
    else if(token == FDT_END_NODE)
    {
        depth--;
        *depth_ptr = depth;
        for(int i = 0; i < depth; i++)uart_puts(" ");
        uart_puts("}\n");
    }
    else if(token == FDT_END)
    {
        depth--;
        *depth_ptr = depth;
        for(int i = 0; i < depth; i++)uart_puts(" ");
        uart_puts("}\n");
    }
}