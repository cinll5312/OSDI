#include "uart.h"
#include "shell.h"
#include "mailbox.h"
#include "reboot.h"
#include "cpio.h"
#include "utli.h"

extern void from_el1_to_el0(unsigned int* addr, unsigned int* stack_addr);
extern void core_timer_enable();
extern void exception_test();


void help(){
	uart_puts("help       : print this menu\n\r");
	uart_puts("hello      : print Hello World!\n\r");
	uart_puts("reboot     : reset the device\n\r");
	uart_puts("version    : print raspi version\n\r");
	uart_puts("memory     : print memory\n\r");
	uart_puts("loadimg    : reload img\n\r");
	uart_puts("ls         : list files\n\r");
	uart_puts("cat        : show file content\n\r");
	uart_puts("devicetree : show devicetree\n\r");
	
}


void hello(){
	uart_puts("Hello World\n");
}

void reboot(){
	reset(100);
	uart_puts("reboot!\n\r");
}

void cancel_reboot(){
	cancel_reset();
}

void version(){
	unsigned int v = get_board_revision();
	uart_puts("Version : ");
	print_hex(v);
}

void mem(){
	get_arm_memory();
}

void loadimg(){
	long load_addr;
	load_addr = 0x60000;//jump to bootloader
	asm volatile(
		"mov x9, 0x60000\n\r"
		"br x9\n\r"::
	);
}

void ls_cpio(){
	lsfile();
}

void cat_cpio(char* file){
	catfile(file);
}

void jump_el1_to_el0(){
	unsigned int* addr = 0x100000;
	load_usr_program("usr.img",addr);
	from_el1_to_el0(addr, 0x100000);
}
//1651076143	761556015	1970170220	1633758584
//basic timer interrupt
// void timer(){
// 	uart_puts("input delay time\n");
// 	char buf[BUF_LEN];
// 	int ret = read(buf, BUF_LEN);
// 	unsigned int t = str2uint(buf);
// 	uart_puts("add time : ");
// 	print_num(t);
// 	uart_puts("\n");
// 	add_timer(t);
// }

void test_asyn_uart(){
	char buf[64];
	int len = asyn_read(buf,64);
	if(len)
	{
		asyn_print(buf);
		uart_puts("\n");
	}
}

void setTimeout()
{
	uart_puts("input delay time\n");
	char buf[BUF_LEN];
	int ret = read(buf, BUF_LEN);
	unsigned int t = str2uint(buf);
	// uart_puts("add time : ");
	// print_num(t);
	// uart_puts("\n");
	add_timer(&uart_cb,t);
}

void shell() {
	char buf[BUF_LEN];
	int ret;
	
	while(1){
		uart_puts("# ");
		
		ret = read(buf, BUF_LEN);
		if(cmpstr(buf, "help",sizeof("help"))){
			help();
		}else if(cmpstr(buf,"hello",sizeof("hello"))){
			hello();
		}else if(cmpstr(buf,"reboot",sizeof("reboot"))){
			reboot();
		}else if(cmpstr(buf,"cancel_reboot",sizeof("cancel_reboot"))){
			cancel_reboot();
		}else if(cmpstr(buf,"version",sizeof("version"))){
			version();
		}else if(cmpstr(buf,"memory",sizeof("memory"))){
			mem();
		}else if(cmpstr(buf,"loadimg",sizeof("loadimg"))){
			loadimg();
		}else if(cmpstr(buf,"ls",sizeof("ls"))){
			ls_cpio();
		}else if(cmpstr(buf,"cat",3)){//do not compare '\0' in cat
			char* file = &buf[4];
			cat_cpio(file);
		}else if(cmpstr(buf,"dv",sizeof("dv"))){
			//fdt_init();
		}else if(cmpstr(buf,"el0",sizeof("el0"))){
			//jump_el1_to_el0();
			from_el1_to_el0(&exception_test, 0x150000);
		}else if(cmpstr(buf,"timer",sizeof("timer"))){
			setTimeout();
		}else if(cmpstr(buf,"asyn",sizeof("asyn"))){
			test_asyn_uart();
		}else if(cmpstr(buf," ",sizeof(" "))){
			uart_puts("command not found\n");
		}
	}
}