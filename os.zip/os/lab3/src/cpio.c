#include "cpio.h"
#include "uart.h"
#include "utli.h"

unsigned int hex2dec(char *s) // hex to decimal int
{
    unsigned int r = 0;
    for (int i = 0; i < 8; ++i)
    {
        if (s[i] >= '0' && s[i] <= '9')
        {
            r = r * 16 + (s[i] - '0');
        }
        else if (s[i] >= 'a' && s[i] <= 'f')
        {
            r = r * 16 + (s[i] - 'a' + 10);
        }
        else if (s[i] >= 'A' && s[i] <= 'F')
        {
            r = r * 16 + (s[i] - 'A' + 10);
        }
    }
    return r;
}

int big2little(unsigned int* num)
{
    unsigned int res = 0;
   *num =   (*num & 0x000000FF) << 24 |
            (*num & 0x0000FF00) << 8  |
            (*num & 0x00FF0000) >> 8  |
            (*num & 0xFF000000) >> 24;

    return res; 
}

void lsfile(){
    long addr = INITRAMFS;
    unsigned int namesize;
    unsigned int filesize;
    while(!cmpstr((char*)addr+sizeof(cpio_t),"TRAILER!!!",sizeof("TRAILER!!!"))){
        cpio_t *head = (cpio_t*)addr;

        namesize = hex2dec(head->c_namesize);
        filesize = hex2dec(head->c_filesize);

        addr += sizeof(cpio_t);
    
        //print file name
        char *s = addr;
        for(int i = 0 ; i < namesize; i++){
            uart_send(*s);
            s++;
        }
        // uart_puts(" ");
        // print_num(filesize);
        //uart_puts("\n");
        if(namesize > 0)
            uart_puts("\n\r");

        addr += namesize;
        addr = (addr%4==0)?addr:addr+4-(addr%4);
        addr += filesize;
        addr = (addr%4==0)?addr:addr+4-(addr%4);

    }
    
}

void catfile(char* target){
    long addr = INITRAMFS;
    unsigned int namesize;
    unsigned int filesize;
    int istarget = 0;
    while(!cmpstr((char*)addr+sizeof(cpio_t),"TRAILER!!!",sizeof("TRAILER!!!"))){
        cpio_t *head = (cpio_t*)addr;

        namesize = hex2dec(head->c_namesize);
        filesize = hex2dec(head->c_filesize);
        
        addr += sizeof(cpio_t);
    

        char *s = addr;
        if(cmpstr((char*)addr,target,namesize)){
            istarget = 1;
        }

        addr += namesize;
        addr = (addr%4==0)?addr:addr+4-(addr%4);

        if(istarget&&filesize>0){
            char*s = addr;
            for(int i = 0; i < filesize; i++){
                uart_send(*s);
                s++;
            }
            uart_puts("\n\r");
            istarget = 0;
            break;
        }

        addr += filesize;
        addr = (addr%4==0)?addr:addr+4-(addr%4);
    }
}

void load_usr_program(char* target, unsigned int* target_addr)
{
    long addr = INITRAMFS;
    unsigned int namesize;
    unsigned int filesize;
    int istarget = 0;
    while(1){
        cpio_t *head = (cpio_t*)addr;

        namesize = hex2dec(head->c_namesize);
        filesize = hex2dec(head->c_filesize);

        addr += sizeof(cpio_t);
    
        if(namesize==11){
            if(cmpstr((char*)addr,"TRAILER!!!",10))break;
        }

        char *s = addr;
        if(cmpstr((char*)addr,target,namesize)){
            istarget = 1;
        }


        addr += namesize;
        addr = (addr%4==0)?addr:addr+4-(addr%4);

        if(istarget&&filesize>0){
            // uart_puts("mov target ");
            // print_num(filesize);
            // uart_puts("\n");
            char* s = addr;
            char* ss = target_addr;
            for(int i = 0; i < filesize; i++){
                *ss = *s;
                s++;
                ss++;
                // print_num(*s);
                // uart_puts("\n");
                //uart_send(s);
            }
            ss = target_addr;
            int size = filesize/8 + (filesize%8==0)?0:1;
            // for(int i = 0; i < size; i++){
            //     big2little(ss);
            //     ss = ss + 8;
            // }
            //uart_puts("\n\r");
            istarget = 0;
            break;
        }

        addr += filesize;
        addr = (addr%4==0)?addr:addr+4-(addr%4);
    }
}

//usr.img size 24
//-763363328	-1862269952	-738197503	-251653089
//1426063275	335544320	
