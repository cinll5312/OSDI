#include "uart.h"
#include "shell.h"
#include "mm.h"
#include "fdt.h"
#include "utli.h"
#include "timer.h"
#include "irq.h"
#include "cpio.h"
extern void exception_test_sample();

void init()
{
	uart_init();
	irq_init();
	time_init();
	mm_init();
	fdt_init();
}

void main(int argc, char *argv[])
{
	fdt_addr =  argc;
    init();
	uart_puts("Basic Shell\n\r");

	while (1) {
		shell();
	}
}