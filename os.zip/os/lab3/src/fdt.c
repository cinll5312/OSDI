#include "fdt.h"
#include "cpio.h"

uint32_t align_up(uint32_t size, int alignment)
{
    return (size + alignment - 1) & -alignment;
}

uint32_t little2big(uint32_t num)
{
    uint32_t res = 0;
    res = (num & 0x000000FF) << 24 |
          (num & 0x0000FF00) << 8  |
          (num & 0x00FF0000) >> 8  |
          (num & 0xFF000000) >> 24;
   
    return res; 
}
//0x801dbdd

 //https://www.kernel.org/doc/Documentation/devicetree/bindings/chosen.txt
//cpio
void parsing_dtb(char* target, int target_len, void *target_addr, dtb_callback_t callback)
{
    char buf[64];
    fdt_header_t* tmp = (fdt_header_t*)FDT_ADDRESS;
    uint32_t magic = little2big(tmp->magic);
    //print_hex(magic);
    if(FDT_MAGIC == magic)
    {
        uint32_t totalsize = little2big(tmp->totalsize);
        uint32_t off_dt_struct = little2big(tmp->off_dt_struct);
        uint32_t off_dt_strings = little2big(tmp->off_dt_strings);
        
        uint32_t size_dt_strings = little2big(tmp->size_dt_strings);
        uint32_t size_dt_struct = little2big(tmp->size_dt_struct);

        char* struct_start = ((char*)(FDT_ADDRESS) + off_dt_struct);
        char* struct_end = (char*)(struct_start + size_dt_struct);
        char* string_start = (char*)((char*)(FDT_ADDRESS) + (uint32_t)off_dt_strings);

        char* addr_start = struct_start;
        while(addr_start < struct_end)
        {
            uint32_t token = little2big(*(uint32_t*)addr_start);

            addr_start += 4;
            if(token == FDT_BEGIN_NODE)
            {
                char* devicename = (char*)addr_start;
                callback(token,devicename,target,target_len,0,target_addr);
                addr_start += sizeof(devicename);
                addr_start += ((uint32_t)addr_start%4==0)?0:(4-(uint32_t)addr_start%4);
            }
            else if(token == FDT_PROP)
            {
                
                uint32_t len = little2big(*((uint32_t*)addr_start));
                addr_start += 4;
                uint32_t nameoff = little2big(*((uint32_t*)addr_start));
                addr_start += 4;
                uint32_t nameoff_strings = string_start + nameoff;
                char* property = (char*)nameoff_strings;
                char *prop_value = (char*)addr_start;
                callback(token,property,target,target_len,prop_value,target_addr);
                addr_start += len;
                addr_start += ((uint32_t)addr_start%4==0)?0:(4-(uint32_t)addr_start%4);
                // uart_puts(property);
                // uart_puts("\n");
            }
            else if(token == FDT_END_NODE)
            {
                callback(token,0,target,target_len,0,target_addr);
            }
            else if(token == FDT_NOP)
            {
                callback(token,0,target,target_len,0,target_addr);
            }
            else if(token == FDT_END)
            {
                callback(token,0,target,target_len,0,target_addr);
            }
            else
            {
                //uart_puts("error type\n");
            }
        }


    }
    else
    {
        uart_puts("error dtb\n");
    }
}

void find_dtb(int node_type, char* name, char* target, int len, void* value, void* target_addr)
{
    if(node_type != FDT_PROP || len == 0)return;
    if(cmpstr(name,target,len))
    {
        // print_num(len);
        // uart_puts(" ");
        // uart_puts(name);
        // uart_puts(" ");
        // print_hex((unsigned int*)value);
        // uart_puts(" ");
        // print_hex(little2big(*(uint32_t*)value));
        // uart_puts("\n");
        *(uint32_t*)target_addr = little2big(*(uint32_t*)value);
    }
}

void fdt_init()
{
    //cpio
    parsing_dtb("linux,initrd-start", sizeof("linux,initrd-start"), &cpio_start, find_dtb);
}
