#include "irq.h"
#include "timer.h"

extern void enable_irq(void);
extern void disable_irq(void);

void irq_handler(unsigned int spsr_el1, unsigned int elr_el1, unsigned int esr_el1)
{
    //uart_puts("irq_handler\n\r");
    disable_irq();
    if(*CORE0_IRQ_SOURCE & (1 << 1))
    {
        add_task_queue(&irq_time_handler,TIMER_T);   
        //irq_time_handler();//basic
    }
    else if(*CORE0_IRQ_SOURCE & (1 << 8))
    {
        //uart_puts("uart interrupt\n");
        add_task_queue(&exe_uart_task_handler,UART_T);
        //uart_interrupt_handler();//basic
    }
    else
    {
        uart_puts("No type\n\r");
        uart_puts("spsr_el1 : ");
        print_hex(spsr_el1);
        uart_puts("\nelr_el1 : ");
        print_hex(elr_el1);
        uart_puts("\nesr_el1 : ");
        print_hex(esr_el1);
        uart_puts("\n");
        //while(1);
        enable_irq();
        return;
    }

    exe_task_queue();

    enable_irq();
}


void irq_init()
{
    //asyn_buf_init
    recv_head = 0;
    recv_tail = 0;
    send_head = 0;
    send_tail = 0;

    //task queue init

    for(int i = 0; i < MAX_TASK_QUEUE_LEN; i++)
    {
        task_queue[i].callback = NULL;
        task_queue[i].next = NULL;
    }
    task_idx = MAX_TASK_QUEUE_LEN;
    task_head = NULL;
    task_tail = NULL;
}


//basic uart interrupt
void uart_interrupt_handler() 
{
    // uart_puts("uart interrupt handler\n");
    volatile unsigned int iir = *AUX_MU_IIR;
    if(*IRQ_PENDING_1 & (1 << 29))
    {
        if ((iir & 1) == 0) 
        {
            if (iir & 2)
            {
                // transmit interrupt
                asyn_send_handler();
            }
            else if (iir & 4)
            {
                // recv interrupt
                asyn_recv_handler();
            }
        } 
        else 
        {
            uart_puts("Aux Interrupt Error \n");
        }
    }
    
}


//basic uart interrupt
void asyn_recv_handler()
{
    char c = uart_recv();
    uart_send(c);
    recv_tail = (recv_tail+1)%LEN;
    recv_buf[recv_tail] = c;
    if (c == '\r') uart_send('\n');
    *AUX_MU_IER |= (1);
}

//basic uart interrupt
void asyn_send_handler()
{
    if(send_head == send_tail)
    {
        *AUX_MU_IER &= ~(1 << 1);
        return;
    }
    send_head = (send_head + 1) % LEN;
    if(send_buf[send_head] != "\0")
    {
        uart_send(send_buf[send_head]);
        *AUX_MU_IER |= (1 << 1);
    }
    else
    {
        uart_puts("\n");
        *AUX_MU_IER &= ~(1 << 1);
    }
    
}

//for test asyn_read
unsigned int asyn_read(char *str, unsigned int size)
{
    disable_irq();
    *AUX_MU_IER |= 1;
    enable_irq();
    int i;
    for(i = 0; i < size-1; i++)
    {
        while(recv_head == recv_tail)
        {
            asm volatile("nop\n\r");
        }
        recv_head = (recv_head + 1) % LEN;
        if(recv_buf[recv_head] == '\r' | recv_buf[recv_head] == '\n')
        {
            
            break;
        }
        else
        {
            
            str[i] = recv_buf[recv_head];
        }
        // uart_puts("asyn read i ");
        // print_num(i);
        // uart_puts("\n");
    }
    str[i] = '\0';
    *AUX_MU_IER &= ~(1);
    return i;
}

void asyn_print(const char *str)
{
    for (int i = 0; str[i] != '\0'; i++) 
    {
        send_tail = (send_tail + 1) % LEN;
        if(str[i] == '\n')
        {
            // uart_puts("newline\n");
            send_buf[send_tail] = str[i];
            send_tail = (send_tail + 1) % LEN;
            send_buf[send_tail] = '\r';
        }
        else
        {
            send_buf[send_tail] = str[i];
        }
    }
    send_tail = (send_tail + 1) % LEN;
    send_buf[send_tail] = '\0';
    // uart_send(send_buf[send_tail]);
    // uart_puts("send tail ");
    // print_num(send_tail);
    // uart_puts("\n");
    if(send_head != send_tail)
    {
        //send not complete
        disable_irq();
        *AUX_MU_IER |= (1 << 1);
        enable_irq();
    }
    else
    {
        *AUX_MU_IER &= ~(1 << 1);
    }
}


void add_task_queue(void (*callback)(), int disable_type)
{
    int valid_task = 0;
    find_task_slot();
    if(task_idx != MAX_TASK_QUEUE_LEN)
    {
        switch(disable_type)
        {
            case UART_T:
                task_queue[task_idx].prio = default_level;
                uart_task_handler(&task_queue[task_idx].buf[0]);
                if(task_queue[task_idx].buf[0] != NULL)
                    valid_task = 1;
                // uart_puts("add task ");
                // uart_send(task_queue[task_idx].buf[0]);
                // uart_puts("\n");
                break;
            case TIMER_T :
                // uart_puts("add task timer\n");
                core_timer_disable();
                task_queue[task_idx].prio = level1;
                //core_timer_enable();
                valid_task = 1;
                break;
            default:
                uart_puts("error type\n");
                break;
        }
        if(valid_task)
        {
            
            task_queue[task_idx].callback = callback;
            task_queue[task_idx].status = WAIT;
            if(task_head == NULL)
            {
                //no task head
                task_queue[task_idx].next = NULL;
                task_head = &task_queue[task_idx];
                task_tail = &task_queue[task_idx];
            }
            else
            {
                if(task_tail->prio >= task_queue[task_idx].prio)
                {
                    task_tail->next = &task_queue[task_idx];
                    task_queue[task_idx].next = NULL;
                    task_tail = &task_queue[task_idx];
                }
                else
                {
                    task_slot_t* tmpp = NULL;
                    task_slot_t* tmp = task_head;
                    int add = 0;
                    while(tmp)
                    {
                        if(tmp->prio < task_queue[task_idx].prio)
                        {
                            add = 1;
                            if(tmpp == NULL)
                            { 
                                task_queue[task_idx].next = tmp;
                                task_head = &task_queue[task_idx];
                            }
                            else
                            {
                                tmpp->next = &task_queue[task_idx];
                                task_queue[task_idx].next = tmp;
                            }
                        }
                        tmpp = tmp;
                        tmp = tmp->next;
                    }
                    if(!add)
                    {
                        task_tail->next = &task_queue[task_idx];
                        task_queue[task_idx].next = NULL;
                        task_tail = &task_queue[task_idx];
                    }
                }
            }
        //     uart_puts("1task list ");
        //     print_hex(task_head);
        //     uart_puts(" ");
        //     print_hex(task_tail);
        //     uart_puts("\n");
        }
        else
        {
            //uart_puts("invalid task\n");
        }
    }
    else
    {
        uart_puts("not free slot for task queue\n");
    }
}

void find_task_slot()
{
    unsigned int tmp = (task_idx + 1) % MAX_TASK_QUEUE_LEN;
    for(int i = 0; i < MAX_TASK_QUEUE_LEN; i++)
    {
        if(task_queue[tmp].callback == NULL)
        {
            task_idx = tmp;
            break;
        }
        tmp = (tmp + 1) % MAX_TASK_QUEUE_LEN;
    }
}

void exe_task_queue()
{
    enable_irq();
    if(task_head != NULL && task_head->status != FINISH)
    {
        // print_hex(task_head);
        // uart_puts(" exe task_queue\n");
        // print_hex(task_head);
        // uart_puts(" ");
        // print_hex(task_head->callback);
        // uart_puts("\n");
        task_head->status = RUN;
        task_head->callback();
        disable_irq();
        task_head->status = FINISH;
        task_head->callback = NULL;
        task_head = task_head->next;
        
        // print_hex(task_head);
        // uart_puts(" ");
        // print_hex(task_tail);
        // uart_puts(" ");
        // print_hex(task_head->next);
        // uart_puts("\n");  
        if(task_head == NULL)
        {
            task_tail = NULL;
        }
    }
    else
    {
        disable_irq();
        //uart_puts("no task\n");
    }
}

void uart_task_handler(void* arg)
{
    // uart_puts("uart_task_handler\n");
    volatile unsigned int iir = *AUX_MU_IIR;
    if(*IRQ_PENDING_1 & (1 << 29))
    {
        if ((iir & 1) == 0) 
        {
            if (iir & 2)
            {
                *AUX_MU_IER &= ~(1 << 1);
                // transmit interrupt
                if(send_head == send_tail)
                {
                    *AUX_MU_IER &= ~(1 << 1);
                    *(unsigned int*)arg = NULL;
                    return;
                }
                send_head = (send_head + 1) % LEN;
                if(send_buf[send_head] != '\0')
                {
                    *(unsigned int*)arg = send_buf[send_head];
                    *AUX_MU_IER |= (1 << 1);//enable
                }
                else
                {
                    *(unsigned int*)arg = send_buf[send_head];
                    *AUX_MU_IER &= ~(1 << 1);//disable
                }
                
            }
            else if (iir & 4)
            {
                *AUX_MU_IER &= ~(1);
                // recv interrupt
                char c = uart_recv();
                recv_tail = (recv_tail+1)%LEN;
                recv_buf[recv_tail] = c;
                *(unsigned int*)arg = recv_buf[recv_tail];
                *AUX_MU_IER |= (1);
            }
        } 
        else 
        {
            uart_puts("Aux Interrupt Error \n");
        }
    }
    
}

void exe_uart_task_handler() 
{
    // uart_puts("exe_uart_task_handler\n");
    // print_num(task_head->buf[0]);
    if (task_head->buf[0] == '\r' || task_head->buf[0] == '\0')
    {
        uart_send("\n");
    } 
    else
    {
        uart_send(task_head->buf[0]);
    }

}
