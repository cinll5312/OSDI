#ifndef _TIMER_H_
#define _TIMER_H_
#include "uart.h"

#define CORE0_TIMER_IRQ_CTRL  ((unsigned int*)0x40000040)
#define CORE1_TIMER_IRQ_CTRL  ((unsigned int*)0x40000044)
#define CORE2_TIMER_IRQ_CTRL  ((unsigned int*)0x40000048)
#define CORE3_TIMER_IRQ_CTRL  ((unsigned int*)0x4000004C)

#define TIME_Q_LEN (128)


typedef struct{
    void (*callback)(void*);
    unsigned int after;
    unsigned int time; //accurate time
    void* data;
    int valid;
}time_task_t;


time_task_t time_queue[TIME_Q_LEN];
unsigned int q_idx;
unsigned int set_task;
unsigned int valid_task_count;

void time_init();
void expire(unsigned long t);
// void add_timer(unsigned long p); // simple version
void showtime();
void timer_handler();
unsigned int get_current_time();
unsigned int get_current_expired();
unsigned int get_frquency();
void add_timer(void (*callback)(void*), unsigned int after);
void irq_time_handler();
int find_next_task();
void find_next_idx();
#endif