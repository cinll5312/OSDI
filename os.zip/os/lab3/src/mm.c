#include "mm.h"



void mm_init(){
    base = (&brk);
    use_addr = 0;
    for(int i = 0; i < MALLOC_SIZE; i++){
        mm_info[i] = 0;
    }
}


void *simple_malloc(int size){
    
    if(size>MALLOC_SIZE)return (char*)0;

    for(int i = 0; i < size;i++){
        mm_info[i] = 1;
    }
    
    void* temp = (unsigned int)(base+use_addr);
    use_addr += size;
    print_hex(temp);
    uart_puts("\n");
    return (void*)temp;
}