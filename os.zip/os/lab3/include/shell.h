#ifndef SHELL_H
#define SHELL_H



void help();
void hello();
void reboot();
void cancel_reboot();
void version();
void mem();
void loadimg();
void ls_cpio();
void cat_cpio(char* file);
void jump_el1_to_el0();
// void timer(); //basic
void test_asyn_uart();
void setTimeout();//advance
void shell();

#endif