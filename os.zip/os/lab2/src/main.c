#include "uart.h"
#include "shell.h"
#include "mm.h"
#include "fdt.h"

void main(int argc, char *argv[]){
	// uart_puts("Basic Shell\n\r");
	char* string = simple_malloc(8);
    uart_init();
	fdt_addr =  argc;
	fdt_init();
	while (1) {
		shell();
	}
}