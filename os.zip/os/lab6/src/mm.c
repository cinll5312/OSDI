#include "mm.h"

void find_ram(int node_type, char* name, char* target, int len, void* value, void* target_addr)
{
    if(ram_find&&cmpstr(name,"reg",sizeof("reg")))
    {
        *(uint32_t*)target_addr = (uint32_t*)value;
        //print_hex(target_addr);
        ram_find = 0;
    }
    if(cmpstr(name,target,len))
    {
        ram_find = 1;
    }
}


void mm_init()
{
    ram_find = 0;
    parsing_dtb("memory@0", sizeof("memory@0"), &ram_start, find_ram);
    uint32_t* ptr = (uint32_t*)((char*)ram_start);
    ram_start = little2big(*ptr);
    ptr++;
    ram_end = little2big(*ptr);


    buddy_start = ram_start;
    buddy_end = ram_end - (ram_end & 0xFFF);
    mem_count = (buddy_end - buddy_start) / MEM_UNIT;
    //simple allocator base
    simple_base = (&brk);
    buddy_info_start = (&brk_end);
    use_addr = 0;
    for(int i = 0; i < MALLOC_SIZE; i++){
        mm_info[i] = 0;
    }
    //reserved mem
    res_mem_ptr = NULL;
    

    frame_init();

    slab_init();
}

void *simple_malloc(int size)
{
    if(size>MALLOC_SIZE)return (char*)0;

    for(int i = 0; i < size;i++){
        mm_info[i] = 1;
    }
    
    void* temp = (unsigned long)(simple_base+use_addr);
    use_addr += size;
    return (void*)temp;
}

void memory_reserved(unsigned long start, unsigned long end)
{
    // uart_puts("start : ");
    // print_hex(start);
    // uart_puts(" end : ");
    // print_hex(end);
    // uart_puts("\n");
    reserved_mem_t* ptr = (reserved_mem_t*)(simple_malloc(sizeof(reserved_mem_t)));
    ptr->start = start - (start & 0xFFF);
    ptr->end = ptr->start + MEM_UNIT;
    while(end > ptr->end)
    {
        ptr->end = ptr->end + MEM_UNIT;
    }

    if(res_mem_ptr == NULL)
    {
        res_mem_ptr = ptr;
    }
    else
    {
        reserved_mem_t* tmp = res_mem_ptr;
        while(tmp->next)
        {
            tmp = tmp->next;
        }
        tmp->next = ptr;
    }
    ptr->next = NULL;
    
    
    uart_puts("[ Reserved memory : ");
    print_hex(ptr->start);
    uart_puts(" ");
    print_hex(ptr->end);
    uart_puts(" ]\n");
}

void startup_allocation()
{
    memory_reserved(0x0000,0x1000);//multicore boot
    memory_reserved(0x80000, &brk_end);//kernel.img + simple allocator
    select_mm_info_addr();
    memory_reserved(buddy_info_start,(buddy_info_start+sizeof(frame_entry_t)*mem_count));//buddy system
    //memory_reserved(cpio_start,cpio_end);//initramfs
}

void select_mm_info_addr()
{
    reserved_mem_t* ptr = res_mem_ptr;
    buddy_info_start = 0;
    while(ptr)
    {
        // uart_puts("[ Reserved memory : ");
        // print_hex(ptr->start);
        // uart_puts(" ");
        // print_hex(ptr->end);
        // uart_puts(" ]\n");

        if(ptr->end > buddy_info_start)
        {
            buddy_info_start = ptr->end;
        }
        ptr = ptr->next;
    }
    // uart_puts("mark buddy addr : ");
    // print_hex(buddy_info_start);
    // uart_puts("\n");
}

void mark_reserved_mm()
{
    //mark as use
    reserved_mem_t* ptr = res_mem_ptr;
    frame_entry_t* tmp;
    while(ptr)
    {
        tmp = buddy_info_start;
        tmp = tmp + (ptr->start)/MEM_UNIT;
        unsigned long count = ((ptr->end) - (ptr->start))/MEM_UNIT;
        while(count)
        {
            // uart_puts("used ");
            // print_hex(tmp->index);
            // uart_puts("\n");
            tmp->val = FRAME_TYPE_USE;
            count--;
            tmp++;
            
        }
        ptr = ptr->next;
    }
}

void frame_init()
{
    int count = 1;
    unsigned long phy_addr = 0;
    reserved_mem_t* ptr = simple_base;
    for(int i = 0; i < FRAME_LEVEL; i++)
    {
        frame_size[i] = count;
        frame_list_head[i] = NULL;
        frame_list_tail[i] = NULL;
        count = count << 1;
    }
    uart_puts("number of 4K : ");
    print_num(mem_count);
    uart_puts("\n");
    count = 0;
    startup_allocation();
    frame_entry_t* slot_addr = buddy_info_start;
    
    for(int i = 0; i < mem_count; i++)
    {
        slot_addr->index = i;
        slot_addr->val =  0;
        slot_addr->next = NULL;
        slot_addr++;
        // print_hex(slot_addr);
        // uart_puts(" ");
    }
    
    mark_reserved_mm();
    //add free to list
    slot_addr = buddy_info_start;
    //print_hex(slot_addr);
    for(int i = 0; i < mem_count; i++)
    {
        if(slot_addr->val != FRAME_TYPE_USE)
        {
            //frame_list_push(slot_addr->val,slot_addr);
            coalesce_frame(slot_addr);
        }
        else
        {
            // uart_puts("used ");
            // print_hex(slot_addr->index);
            // uart_puts("\n");
        }
        slot_addr++;
        // print_hex(slot_addr);
        // uart_puts(" ");
    }

    slot_addr = frame_list_head[0];

    
    for(int i = 0; i < FRAME_LEVEL; i++)
    {
        // uart_puts("level ");
        // print_num(i);
        // uart_puts(" size ");
        // print_num(frame_size[i]);
        // uart_puts(" : ");
        // pp(i);
        // uart_puts("\n");
    }
    // uart_puts("finish\n");
}

void* kmalloc(int size)
{
    if(size < 0)
    {
        return NULL;
    }
    if(size >= slab_pool_size[SLAB_LEVEL-1])//size > MEM_UNIT
    {
        for(int i = 0; i < FRAME_LEVEL; i++)
        {
            if(size <= frame_size[i]*MEM_UNIT)
            {
                // uart_puts("\ntarget order : ");
                // print_num(i);
                // uart_puts("\n");
                frame_entry_t* ptr = buddy_allocate(i);
                if(ptr != NULL)
                    return (buddy_start + ptr->index * MEM_UNIT);
            }
        }
    }
    else
    {
        return slab_allocator(size);
    }
    
    return NULL;
}

void kfree(void* ptr)
{
    int ret = slab_free(ptr);
    uart_puts("free in slab\n");
    if(ret == 0)
    {
        uart_puts("free in buddy system\n");
        buddy_free(ptr);
    }
}

void buddy_free(void* ptr)
{
    int idx = (int)((char*)ptr - buddy_start) / MEM_UNIT;
    frame_entry_t* tmp = (frame_entry_t*)buddy_info_start + idx;
    // uart_puts("free id : ");
    // print_num(idx);
    // uart_puts("\n");
    int size = 1 << tmp->val;
    for(int i = idx + 1; i < idx + size; i++)
    {
        tmp->val = FRAME_TYPE_FREE;
    }
    if(tmp->val < FRAME_LEVEL)
    {
        coalesce_frame(tmp);
    }
    else
    {
        //the highest level no need to merge
        frame_list_push(tmp->val, idx);
    }
}

int find_buddy_pfn(int order, unsigned long page_pfn)
{
	return page_pfn ^ (1 << order);
}



frame_entry_t* buddy_allocate(int order)
{
    frame_entry_t* ptr;
    for(int i = order; i < FRAME_LEVEL; i++)
    {
        if(frame_list_head[i] != NULL)
        {
            // uart_puts("allocate level : ");
            // print_num(i);
            // uart_puts("\n");
            ptr = frame_list_pop(i);
            // uart_puts(" size : ");
            int size = 1 << ptr->val;
            // print_num(size);
            // uart_puts(" index : ");
            // print_num(ptr->index);
            // uart_puts("\n");
            return frame_free_redundant(order, ptr);
        }
    }
    return NULL;
}

frame_entry_t* frame_list_pop(int order)
{
    frame_entry_t* ptr = frame_list_head[order];
    //pp(order);
    // uart_puts("pop ist idx : ");
    // print_num(frame_list_head[order]->index);
    // uart_puts("\n");
    if(frame_list_head[order] != frame_list_tail[order])
    {
        frame_list_head[order] = frame_list_head[order]->next;
    }
    else
    {
        frame_list_head[order] = NULL;
        frame_list_tail[order] = NULL;
    }
    ptr->next = NULL;
    return ptr;
}

void frame_list_push(int order, frame_entry_t* frame)
{
    if(frame_list_tail[order] != NULL)
    {
        frame_list_tail[order]->next = frame;
        frame_list_tail[order] = frame_list_tail[order]->next;
    }
    else
    {
        frame_list_head[order] = frame;
        frame_list_tail[order] = frame;
        
    }
    frame->next = NULL;
    // frame->next = NULL;
    // print_num(order);
    // uart_puts(" list ");
    // print_num(frame_list_head[order]->index);
    // uart_puts(" ");
    // print_num(frame_list_tail[order]->index);
    // uart_puts("\n");
    // uart_puts(" tail idx : ");
    // print_num(frame_list_tail[order]->index);
    // uart_puts("\n");
}

void frame_list_remove(int order, frame_entry_t* frame)
{
    frame_entry_t* tmp = frame_list_head[order];
    frame_entry_t* pre = NULL; 
    while(tmp)
    {
        if(tmp == frame)
        {
            if(!pre)
            {
                //head
                if(frame_list_head[order] == frame_list_tail[order])
                {
                    //only one element
                    frame_list_head[order] = NULL;
                    frame_list_tail[order] = NULL;
                }
                else
                {
                    frame_list_head[order] = frame_list_head[order]->next;
                }
            }
            else
            {
                if(tmp == frame_list_tail[order])
                {
                    frame_list_tail[order] = pre;
                    pre->next = NULL;
                }
                else
                {
                    pre->next = tmp->next;
                }
            }
        }
        pre = tmp;
        tmp = tmp->next;
    }
    frame->next = NULL;
}

frame_entry_t* frame_free_redundant(int order, frame_entry_t* ptr)
{
    
    int order_size = (1 << order);
    int total_size = (1 << ptr->val);
    int res_size = (1 << ptr->val) - order_size;
    int max_order = ptr->val;
    // uart_puts("order size : ");
    // print_num(order_size);
    // uart_puts(" total_size : ");
    // print_num(total_size);
    // uart_puts(" res_size : ");
    // print_num(res_size);
    // uart_puts("\n");
    frame_entry_t* tmp = ptr;
    ptr->val = order;
    tmp++;
    order_size--;
    for(int i = 0; i < order_size; i++)
    {   
        tmp->val = FRAME_TYPE_USE;
        tmp++;
    }

    if(res_size > 0)
    {
        //cut from tail to head
        // uart_puts("cut space ");
        // print_hex(res_size);
        // uart_puts("\n");
        tmp = tmp + res_size;
        for(int i = max_order - 1; i >= 0; i--)
        {
            // uart_puts("add level ");
            // print_num(i);
            // uart_puts(" ");
            while(res_size >= (1 << i))
            {
                unsigned long mem = (buddy_start + (((tmp->index) - (unsigned long)(1<<i) )* MEM_UNIT));
                // print_hex(mem);
                // uart_puts(" ");
                
                tmp = tmp - (unsigned long)(1 << i);
                tmp->val = i;
                frame_list_push(i,tmp);
                
                res_size -= (1 << i);
            }
            // uart_puts("\n");
        }
    }
    // p();
    return ptr;
}

//merge
void coalesce_frame(frame_entry_t* ptr)
{
    int order = ptr->val;
    int idx = ptr->index;
    int next_buddy_pfn = find_buddy_pfn(order, idx);
    
    frame_entry_t* next = ptr + (next_buddy_pfn - ptr->index);
    // uart_puts("now buddy : ");
    // print_num(ptr->index);
    // uart_puts(" ");
    // print_num(next_buddy_pfn);
    // uart_puts(" ");
    // uart_puts("next buddy : ");
    // print_num(next->index);
    // uart_puts("\n");
    while(in_buddy_system(order, next))
    {
        // uart_puts("merge idx with : ");
        // print_num(next_buddy_pfn);
        // uart_puts(" with order : ");
        // print_num(order);
        // uart_puts("\n");
        // if(1)
        //     pp(order);
        frame_list_remove(order, next);
        // if(1)
        //     pp(order);
        order++;
        ptr->val = FRAME_TYPE_FREE;
        next->val = FRAME_TYPE_FREE;
        idx = next_buddy_pfn & idx;
        next_buddy_pfn = find_buddy_pfn(order, idx);
        next = ptr + (next_buddy_pfn - ptr->index);
        // uart_puts("next idx : ");
        // print_num(next_buddy_pfn);
        // uart_puts(" next order ");
        // print_num(order);
        // // uart_puts(" next buddy : ");
        // // print_num(next->index);
        // uart_puts("\n");
    }
    // print_num(idx);
    // uart_puts(" order ");
    // print_num(order);
    // uart_puts(" push ");
    next = ptr + (idx - ptr->index);
    frame_entry_t* push_target = buddy_info_start;
    push_target += idx;
    push_target->val = order;
    frame_list_push(order,push_target);
    // print_num(push_target->index);
    // uart_puts("\n");
    
    // if(1)
    //     pp(order);
    // uart_puts("\n");
}

int in_buddy_system(int order, frame_entry_t* ptr)
{
    if(order == FRAME_LEVEL-1)return 0;
    frame_entry_t* tmp = frame_list_head[order];
    while(tmp)
    {
        if(tmp == ptr)
        {
            return 1;
        }
        tmp = tmp->next;
    }
    return 0;
}


void* get_one_frame()
{
    frame_entry_t* ptr = buddy_allocate(0);
    if(ptr != NULL)
    {
		// print_hex((buddy_start + (ptr->index) * MEM_UNIT));
		// uart_puts("\n");
        return (buddy_start + (ptr->index) * MEM_UNIT);
    }
        
}

void slab_init()
{
    for(int i = 0; i < SLAB_LEVEL; i++)
    {
        slab_cache[i] = slab_cache_create(slab_pool_size[i]);
        uart_puts("slab pool ");
        print_hex(slab_cache[i]);
        uart_puts(" \n");
    }
}

void* slab_cache_create(int size)
{
    frame_entry_t* frame = buddy_allocate(5);
    void* ptr = (buddy_start + frame->index * MEM_UNIT);
    
    cache_info_t* tmp = (cache_info_t*)ptr;
    int f_size = frame_size[5];
    tmp->total_size = f_size * MEM_UNIT;
    tmp->size = size;
    tmp->valid = (f_size * MEM_UNIT - sizeof(cache_info_t)) / (sizeof(slab_entry_t) + size) - 1;//last is end
    print_num(tmp->valid);
    uart_puts(" ");
    slab_entry_t* slot = (slab_entry_t*)(tmp+1);//slot info
    void* addr_ptr = (void*)(slot + tmp->valid);//free space

    tmp->valid_pool = slot;
    tmp->use_pool = NULL;
    tmp->next = NULL;

    //init slot info
    for(int i = 0; i < tmp->valid; i++)
    {
        slot->used = SLAB_FREE;
        slot->addr = addr_ptr;
        slot->next = slot+1;
        slot++;
        addr_ptr = (void*)((char*)addr_ptr+size);
    }
    slot->next = NULL;//last
    return ptr;
}

void* slab_allocator(int size)
{
    for(int i = 0; i < SLAB_LEVEL; i++)
    {
        if(size <= slab_pool_size[i])
        {
            cache_info_t* tmp = slab_cache[i];
            cache_info_t* pre = NULL;
            while(tmp->valid == 0)
            {
                pre = tmp;
                tmp = tmp->next;
            }
            if(tmp != NULL)
            {
                return get_slab_slot(tmp);
            }
            else
            {
                pre->next = slab_cache_create(slab_pool_size[i]);
                return get_slab_slot(pre->next);
            }
        }
    }
}

void* get_slab_slot(cache_info_t* ptr)
{
    slab_entry_t* tmp = ptr->valid_pool;
    ptr->valid_pool = tmp->next;
    ptr->valid--;
    tmp->next = ptr->use_pool;
    ptr->use_pool = tmp;
    tmp->used = SLAB_USE;
    return tmp->addr;
}

void free_slab_slot(cache_info_t* ptr, void* addr)
{
    slab_entry_t* tmp = ptr->use_pool;
    slab_entry_t* pre = NULL;
    while(tmp)
    {
        if(tmp->addr == addr)
        {
            if(pre == NULL)
            {
                ptr->use_pool = tmp->next;
            }
            else
            {
                pre->next = tmp->next;

            }
            tmp->next = ptr->valid_pool;
            ptr->valid_pool = tmp;
            break;
        }
        pre = tmp;
        tmp = tmp->next;
    }
    tmp->used = SLAB_FREE;
    ptr->valid++;
    return tmp->addr;
}

int slab_free(void* ptr)
{
    int istarget = 1;
    for(int i = 0; i < SLAB_LEVEL && istarget; i++)
    {
        cache_info_t* tmp = slab_cache[i];
        while(tmp)
        {
            if((char*)tmp <= (char*)ptr && (char*)tmp + tmp->total_size >= (char*)ptr)
            {
                
                free_slab_slot(tmp,ptr);
                return 1;
            }
            tmp = tmp->next;
        }
    }
    return 0;
}

//debug
void p()
{
    // for(int i = 32; i < 64; i++)
    // {
    //     print_num(frame_array[i].index);
    //     uart_puts("  val: ");
    //     print_num(frame_array[i].val);
    //     uart_puts("\n");
    // }
}

void pp(int order)
{
    if(order == (FRAME_LEVEL))return;
    frame_entry_t* tmp = frame_list_head[order];
    print_num(order);
    uart_puts(" order list : ");
    while(tmp)
    {
        print_num(tmp->index);
        uart_puts(" ");
        tmp = tmp->next;
    }
    uart_puts("\n");
}
