#include "uart.h"
#include "shell.h"
#include "mm.h"
#include "fdt.h"
#include "utli.h"
#include "timer.h"
#include "irq.h"
#include "cpio.h"
#include "schedule.h"

extern void from_el1_to_el0(unsigned int* addr, unsigned int* stack_addr);
extern void exception_test();


void init()
{
	uart_init();
	irq_init();
	time_init();
	fdt_init();
	mm_init();
	schedule_init();
}
void foo(){
    for(int i = 0; i < 10; ++i) {
		uart_puts("Thread id: ");
		print_num(current_task->id);
		uart_puts(" iter : ");
		print_num(i);
		uart_puts("\n");
    }
}

void main(int argc, char *argv[])
{
	fdt_addr =  argc;
    init();
	// uart_puts("Basic Shell\n\r");
	//from_el1_to_el0(&get_el_c,0x150000);
	// for(int i = 0; i < 3; ++i) { // N should > 2
    //     thread_create(foo);
    // }
    //schedule();
	// time_tick();
	// thread_create(idle);
	
	// while (1) {
	// 	shell();
	// }
}