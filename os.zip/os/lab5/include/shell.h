#ifndef SHELL_H
#define SHELL_H

// #include "syscall.h"
#include "mailbox.h"
#include "reboot.h"
#include "cpio.h"
#include "utli.h"
#include "uart.h"

void help();
void hello();
void reboot();
void cancel_reboot();
void version();
void mem();
void loadimg();
void ls_cpio();
void cat_cpio(char* file);
void jump_el1_to_el0();
// void timer(); //basic
void test_asyn_uart();
void setTimeout();//advance
void shell();

void user_help();
int user_pid();
void user_read();
void user_write(char* buf);
void user_mbox_call();
void user_fork();
void user_handler();
void user_register();
void user_shell();
#endif