#ifndef _SCHEDULE_H_
#define _SCHEDULE_H_
#include "mm.h"
#include "stdint.h"
#include "uart.h"
// #include "syscall.h"
#include "shell.h"
#include "irq.h"

#define MAX_TASK_NUM                (100)
#define THREAD_SIZE		            (4096)//4K
#define PF_UTHREAD                  (0x00000001)
#define PF_KTHREAD                  (0x00000002)
#define STACK_ALIGN                 (32)

#define   SIGKILL                   (9)

#define SIGREG_NUM                  (13)//store 13 regs -->13*8
extern int nr_tasks;
int preemptable;
enum{
    TASK_EMPTY,
    TASK_WAITING,
    TASK_RUNNING,
    TASK_ZOMBIE
};

struct cpu_context {
    // ARM calling convention
    // x0 - x18 can be overwritten by the called function
    uint64_t x19;
    uint64_t x20;
    uint64_t x21;
    uint64_t x22;
    uint64_t x23;
    uint64_t x24;
    uint64_t x25;
    uint64_t x26;
    uint64_t x27;
    uint64_t x28;
    uint64_t fp;  // x29  //user --> sp_el0  //kernel-->sp
    uint64_t lr;  // x30
    uint64_t sp;
    uint64_t sp_el0;
    uint64_t spsr_el1;
    uint64_t elr_el1;
    uint64_t esr_el1;
    uint64_t pc;
};


//for syscall
typedef struct trapframe{
    uint64_t reg[31]; // general register from x0 ~ x30
    uint64_t sp_el0;
    uint64_t elr_el1;
    uint64_t spsr_el1;
}trapframe_t;

typedef struct signal_struct signal_struct_t;
struct signal_struct{
    int signal_num;
    int mask;
};

typedef struct sighand_struct sighand_struct_t;
struct sighand_struct{
    void* handler;
    int signal_num;
    int pid;
    int flag;
};

// signal_struct_t register_signal;

typedef struct task task_t;
struct task{
    uint32_t id;
    uint32_t priority;
    int status;
    unsigned long func_ptr;
    int preempt_count;
    void* userStackptr;
    void* kernelStackptr;
    struct cpu_context reg;
    task_t* next;
    unsigned long flag;
    signal_struct_t signal;
    sighand_struct_t sighand;
};//128

typedef struct{
    task_t* head;
    task_t* tail;
}task_queue_t;



task_t task_pool[MAX_TASK_NUM];

task_queue_t* run_queue;
task_queue_t* wait_queue;
task_t* current_task;

void preempt_disable();
void preempt_enable();
int find_empty_task_slot();
task_t* add_task(unsigned long clone_flags, unsigned long fn, unsigned long arg, int priority);
int copy_process(unsigned long clone_flags, unsigned long fn, unsigned long arg, void* trapframe);
void send_signal(int pid, int signum);
int check_valid_signal();
void check_pending_signal();
void do_signal();
void setup_rt_frame(void* regs);
void schedule();
void kill_zombies();
void time_tick();
void start_user_shell();
void new_kthread(void* kfptr, int kpriority);
void schedule_init();
void queue_init(task_queue_t* queue);
void queue_push(task_queue_t* queue, task_t* task);
void queue_push_p(task_queue_t* queue, task_t* task);//push by priority
task_t* queue_pop(task_queue_t* queue);
int queue_empty(task_queue_t* queue);
#endif