#ifndef _SYSCALL_H_
#define _SYSCALL_H_

#define   SYS_GETPID        (0) 
#define   SYS_UART_READ     (1)
#define   SYS_UART_WRITE    (2)
#define   SYS_EXEC          (3)
#define   SYS_FORK          (4)
#define   SYS_EXIT          (5)
#define   SYS_MBOX_CALL     (6)
#define   SYS_KILL          (7)
#define   SYS_SIGNAL        (8)
#define   SYS_KILL2         (9)
#define   SYS_SIGRETURN     (10)




#include "stdint.h"
#include "schedule.h"
#include "mailbox.h"
#include "utli.h"
//enter kernel and store user mode reg under sp




void sys_getpid(trapframe_t* trapframe);
size_t sys_uart_read(trapframe_t* trapframe);
size_t sys_uart_write(trapframe_t* trapframe);
int sys_exec(trapframe_t* trapframe);
void sys_fork(trapframe_t* trapframe);
void sys_exit(trapframe_t* trapframe);
int sys_mbox_call(trapframe_t* trapframe);
void sys_kill(trapframe_t* trapframe);
void sys_signal(trapframe_t* trapframe);
void sys_kill2(trapframe_t* trapframe);
void sys_sigreturn(trapframe_t* trapframe);
void sync_exc_router(unsigned long esr, unsigned long elr, trapframe_t* trapframe); 
void sys_call_router(uint64_t sys_call_num, trapframe_t* trapframe);
#endif
