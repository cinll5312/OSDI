#ifndef _IRQ_H_
#define _IRQ_H_
#include "gpio.h"
#include "uart.h"
#include "utli.h"
#include "schedule.h"
#define LEN 512
#define MAX_TASK_QUEUE_LEN 128

//for uart asyn buf
unsigned int recv_head;
unsigned int recv_tail;
unsigned int send_head;
unsigned int send_tail;

unsigned int recv_buf[LEN];
unsigned int send_buf[LEN];

#define CORE0_IRQ_SOURCE        ((volatile unsigned int *)(0x40000060))
#define GPU_INTERRUPTS_ROUTING  ((volatile unsigned int *)(0x4000000C))
#define IRQ_BASIC_PENDING	    ((volatile unsigned int *)(MMIO_BASE+0x0000B200))
#define IRQ_PENDING_1		    ((volatile unsigned int *)(MMIO_BASE+0x0000B204))
#define IRQ_PENDING_2		    ((volatile unsigned int *)(MMIO_BASE+0x0000B208))
#define FIQ_CONTROL		        ((volatile unsigned int *)(MMIO_BASE+0x0000B20C))
#define ENABLE_IRQS_1		    ((volatile unsigned int *)(MMIO_BASE+0x0000B210))
#define ENABLE_IRQS_2		    ((volatile unsigned int *)(MMIO_BASE+0x0000B214))
#define ENABLE_BASIC_IRQS	    ((volatile unsigned int *)(MMIO_BASE+0x0000B218))
#define DISABLE_IRQS_1		    ((volatile unsigned int *)(MMIO_BASE+0x0000B21C))
#define DISABLE_IRQS_2		    ((volatile unsigned int *)(MMIO_BASE+0x0000B220))
#define DISABLE_BASIC_IRQS	    ((volatile unsigned int *)(MMIO_BASE+0x0000B224))

typedef struct {
    int prio; // priority
    int status;
    void (*callback)();
    char buf[1];
    void* next;
}task_slot_t;

task_slot_t task_queue[MAX_TASK_QUEUE_LEN];
unsigned int task_idx; // for free slot
task_slot_t* task_head;// for doing task idx
task_slot_t* task_tail;
enum TASK_TYE{
    UART_T,
    TIMER_T
};

enum TASK_PRIORITY{
    level0,
    level1,
    default_level
};

enum TASK_STATUS{
    WAIT,
    RUN,
    FINISH
};

void irq_init();
void irq_handler(unsigned int spsr_el1, unsigned int elr_el1, unsigned int esr_el1);
void uart_interrupt_handler();
void uart_recv_to_buf();
unsigned int asyn_read(char *str, unsigned int size);
void asyn_print(const char *str);
void add_task_queue(void (*callback)(), int disable_type);
void find_task_slot();
void exe_task_queue();
void kirq_handler();
void uart_task_handler(void* arg);
void exe_uart_task_handler();
#endif