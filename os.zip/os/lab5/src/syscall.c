#include "syscall.h"

extern void ret_from_fork();
extern void exit_kernel();
extern void ret_to_user();
void sys_getpid(trapframe_t* trapframe)
{
    trapframe->reg[0] = current_task->id;
	//uart_puts("sys_getpid\n");
}

size_t sys_uart_read(trapframe_t* trapframe)
{
    // uart_puts("sys_uart_read\n");
    char* buf = trapframe->reg[0];
    int size = trapframe->reg[1];
    trapframe->reg[0] = asyn_read(buf,size);
}

size_t sys_uart_write(trapframe_t* trapframe)
{
    char* buf = trapframe->reg[0];
    asyn_print(buf);
	//uart_puts("sys_write\n");
}

int sys_exec(trapframe_t* trapframe)
{
    do_exec(trapframe->reg[0]);
	uart_puts("sys_exec\n");
}

void sys_fork(trapframe_t* trapframe)
{
    int pid = copy_process(PF_UTHREAD, trapframe->reg[30], NULL, trapframe);
    //uart_puts(" sys_fork\n");
}

void sys_exit(trapframe_t* trapframe)
{
    current_task->status = TASK_ZOMBIE;
    schedule();
	//uart_puts("sys_exit\n");
}

int sys_mbox_call(trapframe_t* trapframe)
{
    unsigned int *mailbox = trapframe->reg[0];
    int ch = trapframe->reg[1];
    mailbox_call(mailbox, ch);  
    trapframe->reg[0] = (unsigned int __attribute__((aligned(16)))*)mailbox[5];
    print_hex(trapframe->reg[0]);
    //uart_puts("sys_mallbox\n");
}

void sys_kill(trapframe_t* trapframe)
{
    // task_pool[trapframe->reg[0]].status = TASK_ZOMBIE;
    current_task->status = TASK_ZOMBIE;
    schedule();
    //uart_puts("sys_kill\n");
}

void sys_signal(trapframe_t* trapframe)
{
    current_task->sighand.signal_num = trapframe->reg[0];
    current_task->sighand.handler = trapframe->reg[1];
    current_task->sighand.pid = current_task->id;
    uart_puts("sys_signal\n");
}


void sys_kill2(trapframe_t* trapframe)
{
    preempt_disable();
    //task_pool[trapframe->reg[0]].status = TASK_ZOMBIE;
    int target_pid = trapframe->reg[0];
    int signum = trapframe->reg[1];
    print_num(target_pid);
    uart_puts("\n");
    send_signal(target_pid, signum);
    preempt_enable();
}

void sys_sigreturn(trapframe_t* trapframe)
{
    preempt_disable();
    unsigned long spel0;
    asm volatile("mrs %0, sp_el0\n\r" : "=r"(spel0):);
    int koffset = sizeof(trapframe_t);
    void* now_ksp = (char*)current_task->kernelStackptr - koffset;
    void* old_ksp = (char*)spel0 - (spel0&0xFFF) + THREAD_SIZE - koffset;//previous store!
    
    for(int i = 0; i < sizeof(trapframe_t); i++)
    {
        *(char*)(now_ksp+i) = *(char*)(old_ksp+i);
    }
    preempt_enable();
}


void sync_exc_router(unsigned long esr, unsigned long elr, trapframe_t* trapframe) 
{
    int ec = (esr >> 26) & 0b111111;
    int iss = esr & 0x1FFFFFF;
    if (ec == 0b010101) {  // system call
        uint64_t syscall_num = trapframe->reg[8];
        sys_call_router(syscall_num, trapframe);
    }
    else
    {
        get_el_c();
        uart_puts("ESR_EL1 ");
        print_hex(esr);
        uart_puts("\nELR_EL1 ");
        print_hex(elr);
        uart_puts("\n");
    }
}




void sys_call_router(uint64_t sys_call_num, trapframe_t* trapframe) 
{
    switch(sys_call_num)
    {
        case SYS_GETPID:
            sys_getpid(trapframe);
            break;
        case SYS_UART_READ:
            sys_uart_read(trapframe);
            break;
        case SYS_UART_WRITE:
            sys_uart_write(trapframe);
            break;
        case SYS_EXEC:
            sys_exec(trapframe);
            break;
        case SYS_FORK:
            sys_fork(trapframe);
            break;
        case SYS_EXIT:
            sys_exit(trapframe);
            break;
        case SYS_MBOX_CALL:
            sys_mbox_call(trapframe);
            break;
        case SYS_KILL:
            sys_kill(trapframe);
            break;
        case SYS_SIGNAL:
            sys_signal(trapframe);
            break;
        case SYS_KILL2:
            sys_kill2(trapframe);
            break;
        case SYS_SIGRETURN :
            sys_sigreturn(trapframe);
            break;
        default:
            break;
    }
}



void * const sys_call_table[] = {sys_getpid, sys_uart_read, sys_uart_write, sys_exec, sys_fork, sys_exit, sys_mbox_call, sys_kill, sys_signal,\
                                sys_kill2, sys_sigreturn};
