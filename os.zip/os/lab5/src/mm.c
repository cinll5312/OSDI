#include "mm.h"

void find_ram(int node_type, char* name, char* target, int len, void* value, void* target_addr)
{
    if(ram_find&&cmpstr(name,"reg",sizeof("reg")))
    {
        *(uint32_t*)target_addr = (uint32_t*)value;
        //print_hex(target_addr);
        ram_find = 0;
    }
    if(cmpstr(name,target,len))
    {
        ram_find = 1;
    }
}


void mm_init()
{
    ram_find = 0;
    parsing_dtb("memory@0", sizeof("memory@0"), &ram_start, find_ram);
    uint32_t* ptr = (uint32_t*)((char*)ram_start);
    ram_start = little2big(*ptr);
    ptr++;
    ram_end = little2big(*ptr);
    //buddy_start = (((unsigned int)(&brk_end) >>3) <<3) + MEM_UNIT;
    buddy_start = 0x10000000;
    base = (&brk);
    use_addr = 0;
    for(int i = 0; i < MALLOC_SIZE; i++){
        mm_info[i] = 0;
    }
    frame_init();
    slab_init();
    //reserved mem
    res_mem_ptr = NULL;
    startup_allocation();
}

void *simple_malloc(int size)
{
    if(size>MALLOC_SIZE)return (char*)0;

    for(int i = 0; i < size;i++){
        mm_info[i] = 1;
    }
    
    void* temp = (unsigned int)(base+use_addr);
    use_addr += size;
    return (void*)temp;
}

void memory_reserved(unsigned int start, unsigned int end)
{
    reserved_mem_t* ptr = (reserved_mem_t*)(simple_malloc(sizeof(reserved_mem_t)));

    ptr->start = start;
    ptr->end = end;
    if(res_mem_ptr == NULL)
    {
        res_mem_ptr = ptr;
    }
    else
    {
        reserved_mem_t* tmp = res_mem_ptr;
        while(tmp)
        {
            tmp = tmp->next;
        }
        tmp = ptr;
    }
    ptr->next = NULL;
}

void startup_allocation()
{
    memory_reserved(0x0000,0x1000);//multicore boot
    memory_reserved(0x80000, &brk);//kernel.img
    memory_reserved(cpio_start,cpio_end);//initramfs
    memory_reserved(&brk,&brk_end);//simple allocator
    memory_reserved(MEM_HEAD,MEM_TAIL);//buddy system
}

void frame_init()
{
    int head = 0;
    int count = 1;

    for(int i = 0; i < FRAME_LEVEL; i++)
    {
        frame_size[i] = count;
        frame_list_head[i] = NULL;
        frame_list_tail[i] = NULL;
        count = count << 1;
    }

    count = 0;
    for(int i = 0; i < MEM_COUNT; i++)
    {
        count++;
        frame_array[i].index = i;
        frame_array[i].val = FRAME_TYPE_FREE;
        frame_array[i].next = NULL;
        if(count == frame_size[5])
        {
            frame_array[head].val = FRAME_LEVEL_6;
            frame_list_push(FRAME_LEVEL_6,&frame_array[head]);
            head = i+1;
            count = 0;
        }
    }
}

void* kmalloc(int size)
{
    if(size < 0)
    {
        return NULL;
    }
    
    if(size > slab_pool_size[SLAB_LEVEL-1])//size > MEM_UNIT
    {
        for(int i = 0; i < FRAME_LEVEL; i++)
        {
            if(size <= frame_size[i])
            {
                // uart_puts("\ntarget order : ");
                // print_num(i);
                // uart_puts("\n");
                frame_entry_t* ptr = buddy_allocate(i);
                if(ptr != NULL)
                    return (MEM_HEAD + ptr->index * MEM_UNIT);
            }
        }
    }
    else
    {
        return slab_allocator(size);
    }
    
    return NULL;
}

void kfree(void* ptr)
{
    int ret = slab_free(ptr);
    // uart_puts("free in slab\n");
    if(ret == 0)
    {
        // uart_puts("free in buddy system\n");
        buddy_free(ptr);
    }
}

void buddy_free(void* ptr)
{
    int idx = (int)((char*)ptr - MEM_HEAD) / MEM_UNIT;
    // uart_puts("free id : ");
    // print_num(idx);
    // uart_puts("\n");
    int size = 1 << frame_array[idx].val;
    for(int i = idx+1; i < idx+size; i++)
    {
        frame_array[i].val = FRAME_TYPE_FREE;
    }
    if(frame_array[idx].val < FRAME_LEVEL)
    {
        coalesce_frame(&frame_array[idx]);
    }
    else
    {
        //the highest level no need to merge
        frame_list_push(frame_array[idx].val, idx);
    }
}

int find_buddy_pfn(int order, unsigned int page_pfn)
{
	return page_pfn ^ (1 << order);
}



frame_entry_t* buddy_allocate(int order)
{
    frame_entry_t* ptr;
    for(int i = order; i < FRAME_LEVEL; i++)
    {
        if(frame_list_head[i] != NULL)
        {
            // uart_puts("allocate level : ");
            // print_num(i);
            //uart_puts("\n");
            ptr = frame_list_pop(i);
            // uart_puts(" size : ");
            int size = 1 << ptr->val;
            // print_num(size);
            // uart_puts(" index : ");
            // print_num(ptr->index);
            // uart_puts("\n");
            return frame_free_redundant(order, ptr);
        }
    }
    return NULL;
}

frame_entry_t* frame_list_pop(int order)
{
    frame_entry_t* ptr = frame_list_head[order];
    //pp(order);
    // uart_puts("pop ist idx : ");
    // print_num(frame_list_head[order]->index);
    // uart_puts("\n");
    if(frame_list_head[order] != frame_list_tail[order])
    {
        frame_list_head[order] = frame_list_head[order]->next;
    }
    else
    {
        frame_list_head[order] = NULL;
        frame_list_tail[order] = NULL;
    }
    ptr->next = NULL;
    return ptr;
}

void frame_list_push(int order, frame_entry_t* frame)
{
    if(frame_list_head[order] != NULL)
    {
        frame_list_tail[order]->next = frame;
        frame_list_tail[order] = frame_list_tail[order]->next;
    }
    else
    {
        frame_list_head[order] = frame;
        frame_list_tail[order] = frame;
    }
    frame = NULL;
    // print_num(order);
    // uart_puts(" tail idx : ");
    // print_num(frame_list_tail[order]->index);
    // uart_puts("\n");
    // if(order != 5);
    //     pp(order);
}

void frame_list_remove(int order, frame_entry_t* frame)
{
    
    if(frame_list_head[order] == frame)
    {
        if(frame_list_tail[order] == frame_list_head[order])
        {
            frame_list_head[order] = NULL;
            frame_list_tail[order] = NULL;
        }
        else
        {
            frame_list_head[order] = frame_list_head[order]->next;
        }
    }
    else
    {
        frame_entry_t* tmp;
        tmp = frame_list_head[order];
        while(tmp->next)
        {
            if(tmp->next == frame)
            {
                if(tmp->next == frame_list_head[order])
                {
                    if(frame_list_head[order] == frame_list_tail[order])
                    {
                        frame_list_tail[order] = frame_list_head[order]->next;
                    }
                    frame_list_head[order] = frame_list_head[order]->next; 
                }
                else
                {
                    frame_entry_t* tmpp = tmp->next;
                    if(tmpp)
                    {
                        tmp->next = tmpp->next;
                    }
                    else
                    {
                        tmp->next = NULL;
                        frame_list_tail[order] = tmp;
                    }
                }
            }
            tmp++;
        }
    }
    frame->next = NULL;
}

frame_entry_t* frame_free_redundant(int order, frame_entry_t* ptr)
{
    
    int order_size = (1 << order);
    int total_size = (1 << ptr->val);
    int res_size = (1 << ptr->val) - order_size;
    int max_order = ptr->val;
    // uart_puts("order size : ");
    // print_num(order_size);
    // uart_puts(" total_size : ");
    // print_num(total_size);
    // uart_puts(" res_size : ");
    // print_num(res_size);
    // uart_puts("\n");
    frame_entry_t* tmp = ptr;
    ptr->val = order;
    tmp++;
    order_size--;
    for(int i = 0; i < order_size; i++)
    {   
        tmp->val = FRAME_TYPE_USE;
        tmp++;
    }

    if(res_size > 0)
    {
        //cut from tail to head
        // uart_puts("cut space ");
        // print_hex(res_size);
        // uart_puts("\n");
        tmp = tmp + res_size;
        for(int i = max_order - 1; i >= 0; i--)
        {
            // uart_puts("add level ");
            // print_num(i);
            // uart_puts(" ");
            while(res_size >= (1 << i))
            {
                uint32_t mem = (MEM_HEAD + (tmp->index-1<<i) * MEM_UNIT);
                // print_hex((char*)mem);
                // uart_puts(" ");
                
                tmp = tmp - (1 << i);
                tmp->val = i;
                frame_list_push(i,tmp);
                
                res_size -= (1 << i);
            }
            // uart_puts("\n");
        }
    }
    //p();
    return ptr;
}

//merge
void coalesce_frame(frame_entry_t* ptr)
{
    int order = ptr->val;
    int idx = ptr->index;
    int next_buddy_pfn = find_buddy_pfn(order, idx);
    // uart_puts("next buddy : ");
    // print_num(next_buddy_pfn);
    // uart_puts("\n");
    while(in_buddy_system(order, &frame_array[next_buddy_pfn]))
    {
    //     uart_puts("merge idx with : ");
    //     print_num(next_buddy_pfn);
    //     uart_puts(" with order : ");
    //     print_num(order);
    //     uart_puts(" next idx : ");
        frame_list_remove(order, &frame_array[next_buddy_pfn]);
        order++;
        ptr->val = order;
        frame_array[next_buddy_pfn].val = FRAME_TYPE_FREE;
        idx = next_buddy_pfn & idx;
        // print_num(idx);
        next_buddy_pfn = find_buddy_pfn(order, idx);
        // uart_puts(" next pfn : ");
        // print_num(next_buddy_pfn);
        // uart_puts("\n");
    }
    // uart_puts("push order level ");
    // print_num(order);
    // uart_puts("\n");
    frame_list_push(order,ptr);
}

int in_buddy_system(int order, frame_entry_t* ptr)
{
    if(order == FRAME_LEVEL-1)return 0;
    frame_entry_t* tmp = frame_list_head[order];
    while(tmp)
    {
        if(tmp == ptr)
        {
            return 1;
        }
        tmp = tmp->next;
    }
    return 0;
}

void* get_one_frame()
{
    frame_entry_t* ptr = buddy_allocate(FRAME_LEVEL_1);
    if(ptr != NULL)
        return (MEM_HEAD + ptr->index * MEM_UNIT);
}

void slab_init()
{
    for(int i = 0; i < SLAB_LEVEL; i++)
    {
        slab_cache[i] = slab_cache_create(slab_pool_size[i]);
        // uart_puts("slab pool ");
        // print_hex(slab_cache[i]);
        // uart_puts(" \n");
    }
}

void* slab_cache_create(int size)
{
    frame_entry_t* frame = buddy_allocate(SLAB_RESERVED);
    void* ptr = (MEM_HEAD + frame->index * MEM_UNIT);
    
    cache_info_t* tmp = (cache_info_t*)ptr;
    int f_size = frame_size[SLAB_RESERVED];
    tmp->total_size = f_size * MEM_UNIT;
    tmp->size = size;
    tmp->valid = (f_size * MEM_UNIT - sizeof(cache_info_t)) / (sizeof(slab_entry_t) + size) - 1;//last is end
    // print_num(tmp->valid);
    // uart_puts(" ");
    slab_entry_t* slot = (slab_entry_t*)(tmp+1);//slot info
    void* addr_ptr = (void*)(slot + tmp->valid);//free space

    tmp->valid_pool = slot;
    tmp->use_pool = NULL;
    tmp->next = NULL;

    //init slot info
    for(int i = 0; i < tmp->valid; i++)
    {
        slot->used = SLAB_FREE;
        slot->addr = addr_ptr;
        slot->next = slot+1;
        slot++;
        addr_ptr = (void*)((char*)addr_ptr+size);
    }
    slot->next = NULL;//last
    return ptr;
}

void* slab_allocator(int size)
{
    for(int i = 0; i < SLAB_LEVEL; i++)
    {
        if(size <= slab_pool_size[i])
        {
            cache_info_t* tmp = slab_cache[i];
            cache_info_t* pre = NULL;
            while(tmp->valid == 0)
            {
                pre = tmp;
                tmp = tmp->next;
            }
            if(tmp != NULL)
            {
                return get_slab_slot(tmp);
            }
            else
            {
                pre->next = slab_cache_create(slab_pool_size[i]);
                return get_slab_slot(pre->next);
            }
        }
    }
}

void* get_slab_slot(cache_info_t* ptr)
{
    slab_entry_t* tmp = ptr->valid_pool;
    ptr->valid_pool = tmp->next;
    ptr->valid--;
    tmp->next = ptr->use_pool;
    ptr->use_pool = tmp;
    tmp->used = SLAB_USE;
    return tmp->addr;
}

void free_slab_slot(cache_info_t* ptr, void* addr)
{
    slab_entry_t* tmp = ptr->use_pool;
    slab_entry_t* pre = NULL;
    while(tmp)
    {
        if(tmp->addr == addr)
        {
            if(pre == NULL)
            {
                ptr->use_pool = tmp->next;
            }
            else
            {
                pre->next = tmp->next;

            }
            tmp->next = ptr->valid_pool;
            ptr->valid_pool = tmp;
            break;
        }
        pre = tmp;
        tmp = tmp->next;
    }
    tmp->used = SLAB_FREE;
    ptr->valid++;
    return tmp->addr;
}

int slab_free(void* ptr)
{
    int istarget = 1;
    for(int i = 0; i < SLAB_LEVEL && istarget; i++)
    {
        cache_info_t* tmp = slab_cache[i];
        while(tmp)
        {
            if((char*)tmp <= (char*)ptr && (char*)tmp + tmp->total_size >= (char*)ptr)
            {
                
                free_slab_slot(tmp,ptr);
                return 1;
            }
            tmp = tmp->next;
        }
    }
    return 0;
}

//debug
void p()
{
    for(int i = 32; i < 64; i++)
    {
        print_num(frame_array[i].index);
        uart_puts("  val: ");
        print_num(frame_array[i].val);
        uart_puts("\n");
    }
}

void pp(int order)
{
    if(order == FRAME_LEVEL_6)return;
    frame_entry_t* tmp = frame_list_head[order];
    print_num(order);
    uart_puts("order list : ");
    while(tmp)
    {
        print_num(tmp->index);
        uart_puts(" ");
        tmp = tmp->next;
    }
    uart_puts("\n");
}
