#ifndef _EXCEPTION_H_
#define _EXCEPTION_H_



void exception_entry(unsigned int type, unsigned int esr, unsigned int elr, unsigned int spsr, unsigned long far);
void invalid_exc_handler(unsigned int type, unsigned int esr, unsigned int elr, unsigned int spsr, unsigned long far);

#endif