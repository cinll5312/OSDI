#include "utli.h"


void *memset(void *s, int c, size_t count){

	// c &=0xFF;//int is 4 bytes
	char* xs = (char*)s;
	for(int i = 0; i < count; i++){
		xs[i] = c;
	}
	return s;
}

int cmpstr(const char* s1, const char* s2, int len){
	for(int i = 0; i < len - 1; i++){//no '\0
		if(s1[i] != s2[i]){
			return 0;
		}
		else if(s1[i]=='\0')
		{
			break;
		}
	}
	return 1;
}

void *memcpy(void *str1, const void *str2, size_t n){
	char* s1, *s2;
	for(int i = 0; i < n; i++){
		s1 = (char*)str1;
		s2 = (char*)str2;
		*s2 = *s1;
		str1++;
		str2++;
	}
}

int strlen(const char* s)
{
	int count = 0;

	while(*s++ != '\0')
		count++;

	return count;
}

void get_el_c()//cannot read in el0
{
	unsigned long el;
	asm volatile(
		"mrs x1, CurrentEL\n\r"
		"lsr x1, x1, #2\n\r"
		"mov %0, x1\n\r":
		"=r"(el) 
		:
	);
    uart_puts("Exception level: ");
	print_num(el);
	uart_puts("\n");
}

int read(char *buf, int len) {
	char c;
	int i;

	for (i = 0; i < len; i++) {
    	c = uart_recv();
    	if (c == 127) { 
			i--;
			uart_puts("\b \b"); 

		}//del
		else
		{
			uart_send(c);
		}
    	
    	if (c == '\n') {
    		c = '\n';
    	//   uart_send('\r');
    		break;
    	}
    	buf[i] = c;
	}
	buf[i] = '\0';
	return i;
}

int shell_listen(char *buf, int len) {
	int i;
	i = uart_read(buf,len);//asyn
	if(i)
		uart_puts("\n");
	// if(buf[0]==CTRL_C)
	// {
		
	// }
	
	return i;
}

unsigned int str2uint(char* s)
{
	unsigned int ret = 0;
	while(*s != '\0')
	{
		ret = 10 * ret + *s-'0';
		s++;
	}
	return ret;
}