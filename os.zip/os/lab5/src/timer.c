#include "timer.h"
#include "uart.h"

extern void core_timer_enable();
extern void core_timer_disable();

void time_init()
{
    q_idx = 0;
    valid_task_count = 0;
    set_task = TIME_Q_LEN;
    for(int i = 0; i < TIME_Q_LEN; i++)
        time_queue[i].valid = 0;
}

void expire(unsigned long t)
{
    unsigned long f;
    asm volatile("mrs %0, cntfrq_el0\n\r" : "=r"(f):);
    asm volatile("msr cntp_tval_el0, %0\n\r":: "r"(t*f));
}

//simple timer version
/*
void add_timer(unsigned long p){

    expire(p);
    core_timer_enable();
}*/

void showtime(){
    int count, f;
    int time = 0;
    asm volatile("mrs %[result], cntpct_el0": [result]"=r"(count));
    asm volatile("mrs %[result], cntfrq_el0": [result]"=r"(f));
    time = count /f;
    uart_puts("current time: ");
    if(time == 0)
        uart_puts("0");
    else
        print_num(time);
    uart_puts("\r\n");
    // uart_puts("\nTimer interrupt\n");
}

void timer_handler(){
    //showtime();
    core_timer_disable();
}

unsigned int get_current_time()
{
    unsigned int tt;
    asm volatile("mrs %0, cntpct_el0" : "=r"(tt):);
    return tt;
}

unsigned int get_current_expired()
{
    unsigned int tt;
    asm volatile("mrs %0, cntp_tval_el0" : "=r"(tt):);
    return tt;
}

unsigned int get_frquency()
{
    unsigned long f;
    asm volatile("mrs %0, cntfrq_el0\n\r" : "=r"(f):);
    return f;
}

void add_timer(void (*callback)(void*), unsigned int after)
{
    if(valid_task_count <= TIME_Q_LEN)
    {
        unsigned int cur_time = get_current_time();
        unsigned int f = get_frquency();
        unsigned int cur_expired = get_current_expired();
        unsigned int af = after * f;

        time_queue[q_idx].callback = (callback);
        time_queue[q_idx].after = after;
        time_queue[q_idx].time = cur_time + af;
        time_queue[q_idx].valid = 1;
        valid_task_count++;
        
        if(cur_expired > af || cur_expired == 0)
        {
            //uart_puts("change expired ");
            core_timer_disable();
            expire(after);
            core_timer_enable();
            set_task = q_idx;
        }
        find_next_idx();
        uart_puts("add timer\n");
    }
    else
    {
        uart_puts("no capacity for task\n");
    }
}

void irq_time_handler()
{
    // uart_puts("go to irq_time_handler\n");
    
    if(time_queue[set_task].valid == 2)
    {
        void (*ptr)() = time_queue[set_task].callback;
        (*ptr)();
    }
    else
    {
        enable_irq();
        timer_handler();
        time_queue[set_task].valid = 0;
        void (*ptr)() = time_queue[set_task].callback;
        (*ptr)();
        set_task = TIME_Q_LEN;
        valid_task_count--;
        disable_irq();
        if(valid_task_count)
        {
            set_task = find_next_task();
            // uart_puts("next task : ");
            // print_num(set_task);
            // uart_puts("\n");
            if(set_task != TIME_Q_LEN)
            {
                if(time_queue[set_task].valid == 2)
                {
                    set_a_tick();
                }
                else
                {
                    core_timer_disable();
                    expire(time_queue[set_task].after);
                    core_timer_enable();
                }
            }
        }
    }
}

int find_next_task()
{
    int min = TIME_Q_LEN;
    unsigned int min_time = -1;
    for(int i = 1; i < TIME_Q_LEN; i++)
    {
        if(time_queue[i].valid == 1)
        {
            if(time_queue[i].time < min_time)
            {
                min_time = time_queue[i].time;
                min = i;
            }
        }
    }
    return min;
}

void find_next_idx()
{
    //find next slot
    if(time_queue[(q_idx + 1) % TIME_Q_LEN].valid == 0)
    {
        q_idx = (q_idx + 1) % TIME_Q_LEN;
    }
    else
    {
        int c = 0;
        int tmp = q_idx;
        while(c < TIME_Q_LEN)
        {
            tmp = (tmp + 1) % TIME_Q_LEN;
            if(!time_queue[tmp].valid)
            {
                q_idx = tmp;
                break;
            }
            c++;
        }
    }
}

void add_time_tick(void (*callback)(void*))
{
    if(valid_task_count <= TIME_Q_LEN)
    {
        time_queue[0].callback = (callback);
        time_queue[0].valid = 2;
        
        core_timer_disable();
        set_a_tick();
        core_timer_enable();
        set_task = 0;
    }
    else
    {
        uart_puts("no capacity for task\n");
    }
}

void set_a_tick()
{
    unsigned long f;
    asm volatile("mrs %0, cntfrq_el0\n\r" : "=r"(f):);
    asm volatile("msr cntp_tval_el0, %0\n\r":: "r"(f>>5));
}