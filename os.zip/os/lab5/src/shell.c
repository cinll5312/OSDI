#include "shell.h"


extern void from_el1_to_el0(unsigned int* addr, unsigned int* stack_addr);
extern void core_timer_enable();
extern void exception_test();
extern void exception_test_sample();
extern void exit();

void help(){
	uart_puts("help       : print this menu\n\r");
	uart_puts("hello      : print Hello World!\n\r");
	uart_puts("reboot     : reset the device\n\r");
	uart_puts("version    : print raspi version\n\r");
	uart_puts("memory     : print memory\n\r");
	uart_puts("loadimg    : reload img\n\r");
	uart_puts("ls         : list files\n\r");
	uart_puts("cat        : show file content\n\r");
	uart_puts("devicetree : show devicetree\n\r");
}


void hello(){
	uart_puts("Hello World\n");
}

void reboot(){
	reset(100);
	uart_puts("reboot!\n\r");
}

void cancel_reboot(){
	cancel_reset();
}

void version(){
	unsigned int v = get_board_revision();
	uart_puts("Version : ");
	print_hex(v);
}

void mem(){
	get_arm_memory();
}

void loadimg(){
	asm volatile(
		"mov x9, 0x60000\n\r"
		"br x9\n\r"::
	);
}

void ls_cpio(){
	lsfile();
}

void cat_cpio(char* file){
	catfile(file);
}

void jump_el1_to_el0(){
	unsigned int* addr = 0x100000;
	load_usr_program("usr.img",addr);
	from_el1_to_el0(addr, 0x100000);
}
//1651076143	761556015	1970170220	1633758584
//basic timer interrupt
// void timer(){
// 	uart_puts("input delay time\n");
// 	char buf[BUF_LEN];
// 	int ret = read(buf, BUF_LEN);
// 	unsigned int t = str2uint(buf);
// 	uart_puts("add time : ");
// 	print_num(t);
// 	uart_puts("\n");
// 	add_timer(t);
	
// }

void test_asyn_uart(){
	char buf[64];
	int len = asyn_read(buf,64);
	if(len)
	{
		asyn_print(buf);
		uart_puts("\n");
	}
}

void setTimeout()
{
	uart_puts("input delay time\n");
	char buf[BUF_LEN];
	int ret = read(buf, BUF_LEN);
	unsigned int t = str2uint(buf);
	// uart_puts("add time : ");
	// print_num(t);
	// uart_puts("\n");
	add_timer(&uart_cb,t);
}

void shell() {
	char buf[BUF_LEN];
	int ret;
	
	while(1){
		uart_puts("# ");
		
		ret = read(buf, BUF_LEN);
		if(cmpstr(buf, "help",sizeof("help"))){
			help();
		}else if(cmpstr(buf,"hello",sizeof("hello"))){
			hello();
		}else if(cmpstr(buf,"reboot",sizeof("reboot"))){
			reboot();
		}else if(cmpstr(buf,"cancel_reboot",sizeof("cancel_reboot"))){
			cancel_reboot();
		}else if(cmpstr(buf,"version",sizeof("version"))){
			version();
		}else if(cmpstr(buf,"memory",sizeof("memory"))){
			mem();
		}else if(cmpstr(buf,"loadimg",sizeof("loadimg"))){
			loadimg();
		}else if(cmpstr(buf,"ls",sizeof("ls"))){
			ls_cpio();
		}else if(cmpstr(buf,"cat",3)){//do not compare '\0' in cat
			char* file = &buf[4];
			cat_cpio(file);
		}else if(cmpstr(buf,"dv",sizeof("dv"))){
			//fdt_init();
		}else if(cmpstr(buf,"el0",sizeof("el0"))){
			//jump_el1_to_el0();
			from_el1_to_el0(&exception_test, 0x150000);
		}else if(cmpstr(buf,"timer",sizeof("timer"))){
			setTimeout();
		}else if(cmpstr(buf,"asyn",sizeof("asyn"))){
			test_asyn_uart();
		}else if(cmpstr(buf," ",sizeof(" "))){
			uart_puts("command not found\n");
		}
	}
}

void user_help()
{
	uart_puts("This is user process\n");
	
}

int user_pid()
{
	return getpid();
}

void user_read()
{
	char buf[64];
	uart_read(buf,64);
	uart_puts(buf);
	uart_puts("\n");
}

void user_write(char* buf)
{
	uart_write(buf);
}

void user_mbox_call()
{
	unsigned int __attribute__((aligned(16))) mailbox[7];
	mailbox[0] = 7 * 4; 
	mailbox[1] = REQUEST_CODE;
	mailbox[2] = GET_BOARD_REVISION; 
	mailbox[3] = 4; 
	mailbox[4] = TAG_REQUEST_CODE;
	mailbox[5] = 0; 
	mailbox[6] = END_TAG;

	unsigned int v = mbox_call(mailbox,8);
	uart_puts("Version : ");
	print_hex(v);
	uart_puts("\n");
}

void pr()
{
	unsigned int spp;
	uart_puts("new exec pid :");
	print_num(user_pid());
	uart_puts("\n");
	asm volatile("mov %0, sp\n\r": "=r"(spp):);
	print_hex(spp);
	asm volatile("mov %0, fp\n\r": "=r"(spp):);
	uart_puts(" fp :");
	print_hex(spp);
	uart_puts("\n");
	exit();
}

void user_fork()
{
	unsigned int spp;
	int ret = 0;
	uart_puts("fork start, pid : ");
	print_num(user_pid());
	uart_puts("\n");
    if ((ret = fork()) == 0) { // child	
		uart_puts("child here, pid :");
		print_num(user_pid());
		uart_puts("\n");
		asm volatile("mov %0, sp\n\r": "=r"(spp):);
		print_hex(spp);
		asm volatile("mov %0, fp\n\r": "=r"(spp):);
		uart_puts(" fp :");
		print_hex(spp);
		uart_puts("\n");
		// if ((ret = fork()) == 0) { // child	
		// 	uart_puts("second child here, pid :");
		// 	print_num(user_pid());
		// 	uart_puts("\n");
		// }
		// else
		// {
		// 	uart_puts("first child here, pid :");
		// 	print_num(user_pid());
		// 	uart_puts("\n");
		// }
		// load_usr_program("usr.img",(INITRAMFS+0x800));
		//exec(&exception_test_sample);
		
		kill2(2,SIGKILL);
		while(1);
	}
	else
	{
		uart_puts("parent here, pid :");
		print_num(user_pid()); 
		uart_puts(" ret :");
		print_num(ret);
		uart_puts("\n");
		
	}
	//unsigned int spp;
	asm volatile("mov %0, sp\n\r": "=r"(spp):);
	print_hex(spp);
	asm volatile("mov %0, fp\n\r": "=r"(spp):);
	uart_puts(" fp :");
	print_hex(spp);
	uart_puts("\n");
}

void user_handler()
{
	unsigned int spp;
	uart_puts("i am user handler\n");
	asm volatile("mov %0, sp\n\r": "=r"(spp):);
	print_hex(spp);
	asm volatile("mov %0, x30\n\r": "=r"(spp):);
	uart_puts(" x30 :");
	print_hex(spp);
	uart_puts("\n");
	uart_puts("return to user\n");
}

void user_register()
{
	signal(SIGKILL,&user_handler);
}

void user_shell()
{
	
	char buf[BUF_LEN];
	int ret;
	uart_puts("Process start, pid : ");
	print_num(user_pid());
	uart_puts("\n");
	unsigned int spp;
	asm volatile("mov %0, sp\n\r": "=r"(spp):);
	print_hex(spp);
	asm volatile("mov %0, fp\n\r": "=r"(spp):);
	uart_puts(" fp :");
	print_hex(spp);
	uart_puts("\n");
	
	user_register();
	user_fork();
	while(1){
		uart_puts("\r#");
		ret = shell_listen(buf, BUF_LEN);
		if(cmpstr(buf, "help",sizeof("help"))){
			user_help();
		}else if(cmpstr(buf,"pid",sizeof("pid"))){
			uart_puts("pid : ");
			print_num(user_pid());
			uart_puts("\n");
		}else if(cmpstr(buf,"read",sizeof("read"))){
			user_read();
		}else if(cmpstr(buf,"write",sizeof("write"))){
			char user_buf[64] = "user_read test\n";
			user_write(user_buf);
		}else if(cmpstr(buf,"mailbox",sizeof("mailbox"))){
			user_mbox_call();
		}else if(cmpstr(buf," ",sizeof(" "))){
			uart_puts("command not found\n");
		}
		else
		{
			uart_puts("pid : ");
			print_num(user_pid());
			uart_puts(" sp : ");
			unsigned int spp;
			asm volatile("mov %0, sp\n\r": "=r"(spp):);
			print_hex(spp);
			uart_puts("\n");
			
		}
	}
}