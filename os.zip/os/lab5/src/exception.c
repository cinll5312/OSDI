#include "uart.h"
#include "exception.h"
#include "utli.h"


/**
 * common exception handler
 */
void exception_entry(unsigned int type, unsigned int esr, unsigned int elr, unsigned int spsr, unsigned long far)
{
    // print out interruption type
    //disable_irq();
    switch(type){
        case 0: uart_puts("synchronous_sp_el0\n"); break;
        case 1: uart_puts("irq_sp_el0\n"); break;
        case 2: uart_puts("fiq_sp_el0\n"); break;
        case 3: uart_puts("serror_sp_el0\n"); break;
        case 4: uart_puts("synchronous_sp_elx\n"); break;
        case 5: uart_puts("irq_sp_elx\n"); break;
        case 6: uart_puts("fiq_sp-elx\n"); break;
        case 7: uart_puts("serror_sp_elx\n"); break;
        case 8: uart_puts("synchronous_aarch64\n"); break;
        case 9: uart_puts("irq_aarch64\n"); break;
        case 10: uart_puts("fiq_aarch64\n"); break;
        case 11: uart_puts("serror_aarch64\n"); break;
        case 12: uart_puts("synchronous_aarch32\n"); break;
        case 13: uart_puts("irq_aarch32\n"); break;
        case 14: uart_puts("fiq_aarch32\n"); break;
        case 15: uart_puts("serror_aarch32\n"); break;
    }

    get_el_c();
    // dump registers
    uart_puts("ESR_EL1 ");
    print_hex(esr);
    uart_puts("\nELR_EL1 ");
    print_hex(elr);
    uart_puts("\nSPSR_EL1 ");
    print_hex(spsr);
    // uart_puts(" FAR_EL1 ");
    // print_hex(far);
    uart_puts("\n");
    // no return from exception for now
    //enable_irq();
    while(1);
}




void invalid_exc_handler(unsigned int type, unsigned int esr, unsigned int elr, unsigned int spsr, unsigned long far)
{
    disable_irq();
    switch(type){
        case 0: uart_puts("synchronous_sp_el0"); break;
        case 1: uart_puts("irq_sp_el0"); break;
        case 2: uart_puts("fiq_sp_el0"); break;
        case 3: uart_puts("serror_sp_el0"); break;
        case 4: uart_puts("synchronous_sp_elx"); break;
        case 5: uart_puts("irq_sp_elx"); break;
        case 6: uart_puts("fiq_sp-elx"); break;
        case 7: uart_puts("serror_sp_elx"); break;
        case 8: uart_puts("synchronous_aarch64"); break;
        case 9: uart_puts("irq_aarch64"); break;
        case 10: uart_puts("fiq_aarch64"); break;
        case 11: uart_puts("serror_aarch64"); break;
        case 12: uart_puts("synchronous_aarch32"); break;
        case 13: uart_puts("irq_aarch32"); break;
        case 14: uart_puts("fiq_aarch32"); break;
        case 15: uart_puts("serror_aarch32"); break;
    }
    uart_puts(", this exception type is not implenent \n");
    get_el_c();
    // dump registers
    uart_puts("ESR_EL1 ");
    print_hex(esr);
    uart_puts("\nELR_EL1 ");
    print_hex(elr);
    uart_puts("\nSPSR_EL1 ");
    print_hex(spsr);
    // uart_puts(" FAR_EL1 ");
    // print_hex(far);
    uart_puts("\n");
    enable_irq();
    while(1);
}


