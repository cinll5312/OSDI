#include "schedule.h"
#include "exception.h"

extern void switch_to(unsigned int pre, unsigned int next, unsigned int flag);
extern int get_current_task();
extern void update_current_task(int idx);
extern void ret_from_fork();
extern void sigreturn();

void preempt_disable()
{
	current_task->preempt_count = 1;
}

void preempt_enable()
{
	current_task->preempt_count = 0;
}

int find_empty_task_slot()
{
    for(int i = 0; i < MAX_TASK_NUM; i++)
    {
        if(task_pool[i].status == TASK_EMPTY)return i;
    }
    return MAX_TASK_NUM;
}

task_t* add_task(unsigned long clone_flags, unsigned long fn, unsigned long arg, int priority)
{
    int idx = find_empty_task_slot();
    if(idx < MAX_TASK_NUM)
    {
        task_pool[idx].status = TASK_RUNNING;
        task_pool[idx].id = idx;
        task_pool[idx].flag = clone_flags;
        task_pool[idx].func_ptr = fn;
        task_pool[idx].next = NULL;
        task_pool[idx].priority = priority;
        task_pool[idx].sighand.flag = 0;
        task_pool[idx].sighand.handler = NULL;
        task_pool[idx].signal.mask = 0;
        queue_push(run_queue,&task_pool[idx]);
        uart_puts("create id ");
        print_num(idx);
        uart_puts("\n");
        return &task_pool[idx];
    }
    return NULL;
}

int copy_process(unsigned long clone_flags, unsigned long fn, unsigned long arg, void* trapframe)
{
    preempt_disable();
    task_t* t = add_task(clone_flags,fn,NULL,current_task->priority);
    if(!t)
        return MAX_TASK_NUM;
    //clear cpu reg
    memzero((unsigned long)(&t->reg),sizeof(struct cpu_context));
    p_q(run_queue);
    //allocate new kernel stack
    
    t->kernelStackptr = (char*)get_one_frame() + THREAD_SIZE;
    t->reg.sp = t->kernelStackptr - sizeof(trapframe_t);//first exit kernel
    //clear trapframe ( new kernel stack)
    memzero((unsigned long)(&t->kernelStackptr-sizeof(trapframe_t)),sizeof(trapframe_t));
    //copy kernel stack
    uint64_t koffset = sizeof(trapframe_t);
    char* parent_ksp = (char*)trapframe;
    char* child_ksp = t->kernelStackptr - koffset;
    for(int i = 0; i < koffset; i++)
    {
        *(child_ksp+i) = *(parent_ksp+i);
    }
    
    if (clone_flags == PF_KTHREAD) {
        t->reg.fp = t->kernelStackptr;
        t->reg.x19 = fn;
        t->reg.x20 = arg;
        t->userStackptr = NULL;
    } 
    else
    {
        t->userStackptr = (char*)get_one_frame() + THREAD_SIZE;
        
        //clear user space
        memzero((unsigned long)(t->userStackptr - THREAD_SIZE),THREAD_SIZE);
        //copy user stack
        uint64_t tmppp = THREAD_SIZE - (((trapframe_t*)trapframe)->sp_el0 & 0xFFF);
        uint64_t uoffset = THREAD_SIZE - (((trapframe_t*)trapframe)->sp_el0 & 0xFFF);
        char* parent_usp = (char*)(((trapframe_t*)trapframe)->sp_el0);
        char* child_usp = t->userStackptr - uoffset;
        for(int i = 0; i < uoffset; i++)
        {
            *(child_usp+i) = *(parent_usp+i);
        }
        t->reg.sp_el0 = t->userStackptr - uoffset;
        t->reg.fp = t->userStackptr - uoffset;
        ((trapframe_t*)child_ksp)->sp_el0 = t->userStackptr - uoffset;
    }
    
    t->reg.lr = ret_from_fork;
    t->reg.pc = ret_from_fork;

    
    
    ((trapframe_t*)child_ksp)->reg[29] = t->reg.fp;//sp
    
    ((trapframe_t*)parent_ksp)->reg[0] = t->id;
    

    if(clone_flags == PF_UTHREAD)
    {
        ((trapframe_t*)child_ksp)->reg[0] = 0;
    }
    
    preempt_enable();
	return 0;
}

void send_signal(int pid, int signum)
{
    if(pid > 0)
    {
        task_pool[pid].signal.signal_num = signum;
        task_pool[pid].signal.mask = 1;
    }
}

int check_valid_signal()
{
    if(current_task->id < 2)return 0;
    if(current_task->sighand.handler == NULL)return 0;
    return 1;
}

void check_pending_signal()
{
    if(current_task->signal.mask)
    {
        if(check_valid_signal())
        {
            //custom handler
            do_signal();
            current_task->signal.mask = 0;
        }
    }
}
void debug()
{
    int he;
    he = 0;
    char* a;
    asm volatile("mov %0, sp\n\r":"=r"(a):);
    uart_puts("debug ");
    print_hex(a);
    uart_puts("\n");
}

void do_signal()
{
    void* tmp = (char*)get_one_frame() + THREAD_SIZE;
    setup_rt_frame((void*)tmp);

    char* new_sp_el0_ptr = (char*)tmp - sizeof(trapframe_t);
    char* now_sp_ptr = current_task->kernelStackptr - sizeof(trapframe_t);

    for(int i = 0; i < sizeof(trapframe_t)-8; i++)
    {
        *(now_sp_ptr+i) = 0;
    }

    ((trapframe_t*)now_sp_ptr)->reg[29] = new_sp_el0_ptr;
    ((trapframe_t*)now_sp_ptr)->reg[30] = &sigreturn;
    ((trapframe_t*)now_sp_ptr)->elr_el1 = current_task->sighand.handler;
    ((trapframe_t*)now_sp_ptr)->sp_el0 = new_sp_el0_ptr;
}

void setup_rt_frame(void* regs)
{
    //uart_puts("setup_rt_frame\n");

    uint64_t koffset = sizeof(trapframe_t);
    char* parent_ksp = (char*)current_task->kernelStackptr - koffset;
    char* user_frame = (char*)regs - koffset;

    for(int i = 0; i < koffset; i++)
    {
        *(user_frame+i) = *(parent_ksp+i);
    }
}

void schedule()
{
    preempt_disable();
    task_t* next_task = queue_pop(run_queue);
    if(next_task!=NULL)
    {
        // uart_puts("current id ");
        // print_num(current_task->id);
        // uart_puts(" sp ");
        // print_hex(current_task->reg.fp);
        // uart_puts(" ");
        // uart_puts(" x30 ");
        // print_hex(current_task->reg.lr);
        // uart_puts(" ");
        // uart_puts("next id ");
        // update_current_task(next_task->id);
        // print_num(next_task->id);
        // uart_puts(" sp ");
        // print_hex(next_task->reg.fp);
        // uart_puts(" x30 ");
        // print_hex(next_task->reg.lr);
        // uart_puts("\n");

        if(current_task->status == TASK_RUNNING)
        {
            queue_push(run_queue, current_task);
        }
        task_t* pre = current_task;
        current_task = next_task;
        current_task->status = TASK_RUNNING;
        //p_r();
        // p_q(run_queue);
        switch_to(&pre->reg,&current_task->reg,current_task->flag);
        // asm volatile("mov sp, %0\n\r":: "r"(current_task->reg.sp));
        //p_r();
    }
    check_pending_signal();
    preempt_enable();
}

void kill_zombies()
{
    // uart_puts("kill\n");
    //preempt_disable();
    for(int i = 0; i < MAX_TASK_NUM; i++)
    {
        if(task_pool[i].status == TASK_ZOMBIE)
        {
            // uart_puts("clear ");
            // print_num(i);
            // uart_puts("\n");
            kfree(current_task->reg.sp);
            task_pool[i].status = TASK_EMPTY;
        }
    }
    //preempt_enable();
}


void start_user_shell()
{
    current_task->flag = PF_UTHREAD;
    current_task->userStackptr = (char*)get_one_frame() + THREAD_SIZE;
    current_task->reg.fp = current_task->userStackptr;
    current_task->reg.sp_el0 = current_task->userStackptr;
    //clear user space
    memzero((unsigned long)(current_task->userStackptr - THREAD_SIZE), THREAD_SIZE);
    rx_interrupt();
    do_exec(&user_shell);
}

void idle()
{
    copy_process(PF_KTHREAD,&start_user_shell,NULL,current_task->kernelStackptr - sizeof(trapframe_t));
    add_time_tick(&time_tick);
    schedule();
	while(1)
	{
        //uart_puts("idele\n");
		kill_zombies();
		//schedule();
	}
}

void time_tick()
{
    //uart_puts("time_tick\n");
    add_time_tick(&time_tick);
    if(current_task->preempt_count > 0)return;
    enable_irq();
    schedule();
}

void new_kthread(void* kfptr, int kpriority)
{
    task_t* t = add_task(PF_KTHREAD, kfptr, NULL, kpriority);
    memzero((unsigned long)(&t->reg),sizeof(struct cpu_context));

    //allocate new kernel stack
    t->reg.sp = (char*)get_one_frame() + THREAD_SIZE - sizeof(trapframe_t);
    t->reg.fp = t->reg.sp;
    t->kernelStackptr = t->reg.sp;
    t->reg.lr = ret_from_fork;

    //clear trapframe ( new kernel stack)
    memzero((unsigned long)(t->reg.sp),sizeof(trapframe_t));
    t->reg.x19 = kfptr;
    t->reg.x20 = NULL;
    t->userStackptr = NULL;
    // uart_puts("idle  ");
    // print_hex(t->id);
    // uart_puts(" ");
    // print_hex(t->reg.sp);
    // uart_puts(" \n");
}

// void init_idle()
// {
//     task_t* t = add_task(PF_KTHREAD, &idle, NULL, 10);
//     //clear cpu reg
//     memzero((unsigned long)(&t->reg),sizeof(struct cpu_context));

//     //allocate new kernel stack
//     t->reg.sp = (char*)get_one_frame() + THREAD_SIZE -sizeof(trapframe_t);
//     t->reg.fp = t->reg.sp;
//     t->kernelStackptr = t->reg.sp;
//     //t->reg.pc = ret_from_fork;
//     t->reg.lr = ret_from_fork;
//     //clear trapframe ( new kernel stack)
//     memzero((unsigned long)(t->reg.sp),sizeof(trapframe_t));
//     t->reg.x19 = &idle;
//     t->reg.x20 = NULL;
//     t->userStackptr = NULL;
//     // uart_puts("idle  ");
//     // print_hex(t->id);
//     // uart_puts(" ");
//     // print_hex(t->reg.sp);
//     // uart_puts(" \n");
// }

void schedule_init()
{
    for(int i = 0; i < MAX_TASK_NUM; i++)
    {
        task_pool[i].status = TASK_EMPTY;
        task_pool[i].next = NULL;
    }
    queue_init(run_queue);
    queue_init(wait_queue);

    //idle task first
    new_kthread(&idle,10);
    current_task = queue_pop(run_queue);
    update_current_task(current_task->id); 
    new_kthread(&kirq_handler,10);
    // uart_puts("init  ");
    // print_hex(current_task->id);
    // uart_puts(" ");
    // print_hex(current_task->reg.x19);
    // uart_puts(" ");
    // print_hex(current_task->kernelStackptr);
    // uart_puts(" \n");
    asm volatile("mov x19, %0\n\r":: "r"(current_task->reg.x19));
    asm volatile("mov sp, %0\n\r":: "r"(current_task->reg.sp));
    asm volatile("mov lr, %0\n\r":: "r"(current_task->reg.lr));
    asm volatile("ret\n\r"); 
}

void do_exec(void (*func)()) {
    trapframe_t* tmp = current_task->kernelStackptr - sizeof(trapframe_t);
    memzero(tmp,0,sizeof(trapframe_t));
    current_task->reg.fp = current_task->userStackptr;
    current_task->reg.sp_el0 = current_task->userStackptr;
    tmp->reg[30] = func;
    tmp->reg[29] = current_task->reg.fp;
    tmp->sp_el0 = current_task->userStackptr;
    tmp->elr_el1 = func;
    tmp->spsr_el1 = 0x340;
    
    // uart_puts("do exec ");
    // print_hex(current_task->userStackptr);
    // uart_puts(" ");
    // print_hex(current_task->kernelStackptr);
    // uart_puts(" \n");
    asm volatile("msr sp_el0, %0" : : "r"(current_task->userStackptr));
    asm volatile("msr elr_el1, %0": : "r"(func));
    asm volatile("msr spsr_el1, %0" : : "r"(0x340));
    asm volatile("mov sp, %0" : : "r"(current_task->kernelStackptr));
    asm volatile("eret");
}

void queue_init(task_queue_t* queue)
{
    queue->head = NULL;
    queue->tail = NULL;
}

void queue_push(task_queue_t* queue, task_t* task)
{
    if(queue->head == NULL)
    {
        queue->head = task;
        queue->tail = task;
    }
    else
    {
        queue->tail->next = task;
        queue->tail = task;
    }
    
}

void queue_push_p(task_queue_t* queue, task_t* task)
{
    if(queue->head == NULL)
    {
        queue->head = task;
        queue->tail = task;
    }
    else
    {
        if(task->priority <= queue->tail->priority)
        {
            //tail
            queue->tail->next = task;
            queue->tail = task;
        }
        else
        {
            task_t* tmp = queue->head;
            task_t* tmpp = NULL;
            while(1)
            {
                if(task->priority > tmp->priority)
                {
                    
                    if(tmp == queue->head)
                    {
                        //head
                        task->next = queue->head;
                        queue->head = task;
                        break;
                    }
                    else 
                    {
                        tmpp->next = task;
                        task->next = tmp;
                        break;
                    }
                }
                tmpp = tmp;
                tmp = tmp->next;
            }
        }
    }
    
}

task_t* queue_pop(task_queue_t* queue)
{
    if(queue->head == NULL)
    {
        return NULL;
    }
    task_t* tmp = queue->head;
    if(queue->head == queue->tail)
    {
        //only one element
        queue->head = NULL;
        queue->tail = NULL;
    }
    else
    {
        queue->head = tmp->next;
    }
    tmp->next = NULL;
    return tmp;
}

task_t* queue_pop_target(task_queue_t* queue, int pid)
{
    if(queue->head == NULL)
    {
        return NULL;
    }
    task_t* tmp = queue->head;
    task_t* tmpp = NULL;
    while(tmp)
    {
        if(tmp->id == pid)
        {
            if(queue->head == queue->tail)
            {
                //only one element
                queue->head = NULL;
                queue->tail = NULL;
                break;
            }
            else if(tmp == queue->head)
            {
                queue->head = tmp->next;
            }
            else if(tmp == queue->tail)
            {
                queue->tail = tmpp;
                tmpp->next = NULL;
            }
            else
            {
                tmpp->next = tmp->next;
            }
        }
        tmpp = tmp;
        tmp = tmp->next;
    }
    tmp->next = NULL;
    uart_puts("pop target\n");
    p_q(run_queue);
    return tmp;
}

int queue_empty(task_queue_t* queue)
{
    return (queue->head == NULL)?1:0;
}

void p_q(task_queue_t* q)
{
    task_t* tmp = q->head;
    while(tmp)
    {
        print_num(tmp->id);
        uart_puts(" ");
        tmp = tmp->next;
    }
    uart_puts("\n");
}

void p_r()
{
    unsigned int spp;
    uart_puts("p_r sp : ");
	asm volatile("mov %0, sp\n\r": "=r"(spp):);
	print_hex(spp);
    uart_puts(" sp_el0 : ");
	asm volatile("mrs %0, sp_el0\n\r" : "=r"(spp):);
	print_hex(spp);
    uart_puts(" lr : ");
	asm volatile("mov %0, x30\n\r" : "=r"(spp):);
	print_hex(spp);
    uart_puts("\n");
    return;
}